function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-edit-product-edit-product-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/edit-product/edit-product.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/edit-product/edit-product.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesEditProductEditProductPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-title>Edit Product</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-grid class=\"ion-padding-horizontal\">\n    <ion-row>\n      <ion-col>\n        <form [formGroup]=\"editForm\" (ngSubmit)=\"submitProduct()\">\n          <ion-item>\n            <ion-label position=\"floating\" class=\"ion-no-padding\">Clothing Item Name <ion-text color=\"danger\">*</ion-text></ion-label>\n            <ion-input required formControlName=\"productName\" type=\"text\"></ion-input>\n          </ion-item>\n          <ion-item>\n            <ion-label position=\"floating\" class=\"ion-no-padding\">Price (GHC) <ion-text color=\"danger\">*</ion-text></ion-label>\n            <ion-input required formControlName=\"price\" type=\"text\"></ion-input>\n          </ion-item>\n          <ion-item>\n            <ion-label position=\"floating\" class=\"ion-no-padding\">Description <ion-text color=\"danger\">*</ion-text></ion-label>\n            <ion-input required formControlName=\"description\" type=\"text\"></ion-input>\n          </ion-item>\n\n          <ion-item class=\"ion-no-padding\">\n            <ion-button (click)=\"chooseOrTakePicture()\" expand=\"block\" fill=\"clear\" shape=\"round\">\n              Choose Image\n            </ion-button>\n          </ion-item>\n          \n          <ion-button block color=\"primary\" type=\"submit\" [disabled]=\"editForm.invalid\">\n            Edit Product\n          </ion-button>\n        </form>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/edit-product/edit-product-routing.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/pages/edit-product/edit-product-routing.module.ts ***!
    \*******************************************************************/

  /*! exports provided: EditProductPageRoutingModule */

  /***/
  function srcAppPagesEditProductEditProductRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditProductPageRoutingModule", function () {
      return EditProductPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _edit_product_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./edit-product.page */
    "./src/app/pages/edit-product/edit-product.page.ts");

    var routes = [{
      path: '',
      component: _edit_product_page__WEBPACK_IMPORTED_MODULE_3__["EditProductPage"]
    }];

    var EditProductPageRoutingModule = function EditProductPageRoutingModule() {
      _classCallCheck(this, EditProductPageRoutingModule);
    };

    EditProductPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], EditProductPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/edit-product/edit-product.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/edit-product/edit-product.module.ts ***!
    \***********************************************************/

  /*! exports provided: EditProductPageModule */

  /***/
  function srcAppPagesEditProductEditProductModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditProductPageModule", function () {
      return EditProductPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _edit_product_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./edit-product-routing.module */
    "./src/app/pages/edit-product/edit-product-routing.module.ts");
    /* harmony import */


    var _edit_product_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./edit-product.page */
    "./src/app/pages/edit-product/edit-product.page.ts");

    var EditProductPageModule = function EditProductPageModule() {
      _classCallCheck(this, EditProductPageModule);
    };

    EditProductPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _edit_product_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditProductPageRoutingModule"]],
      declarations: [_edit_product_page__WEBPACK_IMPORTED_MODULE_6__["EditProductPage"]]
    })], EditProductPageModule);
    /***/
  },

  /***/
  "./src/app/pages/edit-product/edit-product.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/pages/edit-product/edit-product.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesEditProductEditProductPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-select {\n  width: 100%;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZWRpdC1wcm9kdWN0L0M6XFxVc2Vyc1xcaHBcXERlc2t0b3BcXGlvbmljX3Byb2plY3RzXFxGaW5hbFByb2plY3RcXHNob3BpZnkvc3JjXFxhcHBcXHBhZ2VzXFxlZGl0LXByb2R1Y3RcXGVkaXQtcHJvZHVjdC5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2VkaXQtcHJvZHVjdC9lZGl0LXByb2R1Y3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUVBLHVCQUFBO0FDQUoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9lZGl0LXByb2R1Y3QvZWRpdC1wcm9kdWN0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1zZWxlY3Qge1xuICAgIHdpZHRoOiAxMDAlO1xuICBcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgfSIsImlvbi1zZWxlY3Qge1xuICB3aWR0aDogMTAwJTtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/pages/edit-product/edit-product.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/pages/edit-product/edit-product.page.ts ***!
    \*********************************************************/

  /*! exports provided: EditProductPage */

  /***/
  function srcAppPagesEditProductEditProductPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditProductPage", function () {
      return EditProductPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _services_product_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../services/product.service */
    "./src/app/services/product.service.ts");
    /* harmony import */


    var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @capacitor/core */
    "./node_modules/@capacitor/core/dist/esm/index.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var Camera = _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Plugins"].Camera;

    var EditProductPage = /*#__PURE__*/function () {
      function EditProductPage(productService, formBuilder, alertController, loadingController, plt, actionSheetController, activatedRoute) {
        _classCallCheck(this, EditProductPage);

        this.productService = productService;
        this.formBuilder = formBuilder;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.plt = plt;
        this.actionSheetController = actionSheetController;
        this.activatedRoute = activatedRoute;
        this.categories = [];
        this.product = {};
        this.formData = new FormData();
        this.id = this.activatedRoute.snapshot.paramMap.get('id');
      }

      _createClass(EditProductPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.editForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            'productName': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, []),
            'price': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, []),
            'description': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, [])
          });
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          var _this = this;

          this.productService.getProduct(this.id).subscribe(function (result) {
            _this.product = result;

            _this.productName.setValue(_this.product.title);

            _this.price.setValue(_this.product.price);

            _this.description.setValue(_this.product.description);
          });
        }
      }, {
        key: "submitProduct",
        value: function submitProduct() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this2 = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    this.formData.append("title", this.productName.value);
                    this.formData.append("price", this.price.value);
                    this.formData.append("description", this.description.value);
                    _context3.next = 5;
                    return this.loadingController.create();

                  case 5:
                    loading = _context3.sent;
                    _context3.next = 8;
                    return loading.present();

                  case 8:
                    this.productService.editProduct(this.product.id, this.formData).subscribe(function (res) {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                        var alert;
                        return regeneratorRuntime.wrap(function _callee$(_context) {
                          while (1) {
                            switch (_context.prev = _context.next) {
                              case 0:
                                _context.next = 2;
                                return loading.dismiss();

                              case 2:
                                _context.next = 4;
                                return this.alertController.create({
                                  header: 'Listing Edited',
                                  message: 'Your product listing has been edited',
                                  buttons: ['OK']
                                });

                              case 4:
                                alert = _context.sent;
                                _context.next = 7;
                                return alert.present();

                              case 7:
                              case "end":
                                return _context.stop();
                            }
                          }
                        }, _callee, this);
                      }));
                    }, function (res) {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                        var alert;
                        return regeneratorRuntime.wrap(function _callee2$(_context2) {
                          while (1) {
                            switch (_context2.prev = _context2.next) {
                              case 0:
                                _context2.next = 2;
                                return loading.dismiss();

                              case 2:
                                _context2.next = 4;
                                return this.alertController.create({
                                  header: 'Listing Edit Failed',
                                  message: 'Failed to edit product listing',
                                  buttons: ['OK']
                                });

                              case 4:
                                alert = _context2.sent;
                                _context2.next = 7;
                                return alert.present();

                              case 7:
                              case "end":
                                return _context2.stop();
                            }
                          }
                        }, _callee2, this);
                      }));
                    });

                  case 9:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "chooseOrTakePicture",
        value: function chooseOrTakePicture() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var image, blob, name;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Plugins"].Camera.getPhoto({
                      quality: 90,
                      allowEditing: false,
                      resultType: _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["CameraResultType"].Base64
                    })["catch"](function (error) {
                      console.log(error);
                    });

                  case 2:
                    image = _context4.sent;

                    // variable image should contain our base64 image
                    if (image) {
                      // convert base64 image to blob
                      blob = this.b64toBlob(image.base64String); //Generate a fake filename

                      name = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 10);
                      this.formData.append('image', blob, name + ".".concat(image.format));
                    }

                  case 4:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "b64toBlob",
        value: function b64toBlob(b64Data) {
          var contentType = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
          var sliceSize = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 512;
          var byteCharacters = atob(b64Data);
          var byteArrays = [];

          for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);
            var byteNumbers = new Array(slice.length);

            for (var i = 0; i < slice.length; i++) {
              byteNumbers[i] = slice.charCodeAt(i);
            }

            var byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
          }

          var blob = new Blob(byteArrays, {
            type: contentType
          });
          return blob;
        }
      }, {
        key: "productName",
        get: function get() {
          return this.editForm.get('productName');
        }
      }, {
        key: "price",
        get: function get() {
          return this.editForm.get('price');
        }
      }, {
        key: "description",
        get: function get() {
          return this.editForm.get('description');
        }
      }]);

      return EditProductPage;
    }();

    EditProductPage.ctorParameters = function () {
      return [{
        type: _services_product_service__WEBPACK_IMPORTED_MODULE_4__["ProductService"]
      }, {
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"]
      }];
    };

    EditProductPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-edit-product',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./edit-product.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/edit-product/edit-product.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./edit-product.page.scss */
      "./src/app/pages/edit-product/edit-product.page.scss"))["default"]]
    })], EditProductPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-edit-product-edit-product-module-es5.js.map