function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-product-detail-product-detail-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/product-detail/product-detail.page.html":
  /*!*****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/product-detail/product-detail.page.html ***!
    \*****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesProductDetailProductDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons> -->\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-item lines=\"none\" [routerLink]=\"\">\n      <ion-avatar slot=\"start\">\n          <img class=\"ava-img\" src=\"../../../assets/default_user.png\">\n      </ion-avatar>\n      <ion-label class=\"ion-no-margin\">\n        <h3>{{ product.user }}</h3>\n        <p>Seller Profile</p>\n      </ion-label>\n    </ion-item>\n    <ion-title>Product Detail</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\" class=\"ion-padding-horizontal\">\n<ion-grid>\n  <ion-row>\n    <ion-col class=\"ion-no-padding\">\n      <ion-slides pager=\"true\" [options]=\"imgConfig\" class=\"product-slides\">\n        <ion-slide>\n          <ion-card>\n            <ion-card-content class=\"ion-no-padding\">\n              <img class=\"prod-img\" src=\"{{ product.image }}\" alt=\"\" />\n            </ion-card-content>\n          </ion-card>\n        </ion-slide>\n      </ion-slides>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col class=\"ion-no-padding\">\n      <div class=\"details ion-text-center\">\n        <!-- <span>{{ product.category }}</span> -->\n        <h2> {{ product.title }}</h2>\n        <p>{{ product.price | currency }}</p>\n\n        <ion-button\n        class=\"action-button\"\n        expand=\"block\"\n        fill=\"solid\"\n        color=\"primary\"\n        type=\"button\"\n        [routerLink]=\"['/checkout', product.id]\"\n        *ngIf=\"notOwner ; else owner\"\n      >\n        <span>Purchase</span>\n      </ion-button>\n\n      <ng-template #owner>\n        <ion-button\n        class=\"action-button\"\n        expand=\"block\"\n        fill=\"solid\"\n        color=\"primary\"\n        type=\"button\"\n        [routerLink]=\"['/edit-product', id]\"\n      >\n        <span>Edit</span>\n      </ion-button>\n      <ion-button\n      class=\"action-button\"\n      expand=\"block\"\n      fill=\"solid\"\n      color=\"danger\"\n      type=\"button\"\n      (click)=\"deleteProduct()\"\n    >\n      <span>Delete</span>\n    </ion-button>\n      </ng-template>\n      </div>\n    </ion-col>\n  </ion-row>\n  <!-- <div class=\"separator ion-margin-vertical\"></div> -->\n  <!-- <ion-row>\n    <ion-col>\n      <div class=\"pick-container\">\n        <div>\n          <ion-text>Color</ion-text>\n        </div>\n        <div class=\"item-container\">\n          <app-product-color *ngFor=\"let item of product.colors\"\n          [color]=\"item.code\"></app-product-color>\n        </div>\n      </div>\n    </ion-col>\n  </ion-row> -->\n  <!-- <div class=\"separator ion-margin-vertical\"></div>\n  <ion-row>\n    <ion-col>\n      <div class=\"pick-container\">\n        <div>\n          <ion-text>Size</ion-text>\n        </div>\n        <div class=\"item-container\">\n          <app-product-size *ngFor=\"let item of product.sizes\"\n          [size]=\"item\"></app-product-size>\n        </div>\n      </div>\n    </ion-col>\n  </ion-row> -->\n  <div class=\"separator ion-margin-vertical\"></div>\n  <ion-row>\n    <ion-col>\n      <ion-text>About</ion-text>\n      <p class=\"about\">{{ product.description }}</p>\n    </ion-col>\n  </ion-row>\n  <div class=\"separator ion-margin-vertical\"></div>\n  <!--<ion-row>\n    <ion-col class=\"ion-no-padding\">\n      <ion-item lines=\"none\" class=\"ion-no-padding\">\n        <ion-text>Overall Score</ion-text>\n        <ion-button\n          slot=\"end\"\n          fill=\"clear\"\n          size=\"small\"\n          shape=\"round\"\n          color=\"primary\"\n        >\n          See All\n        </ion-button>\n      </ion-item>\n      <app-review-counter [data]=\"product.reviews\"></app-review-counter>\n    </ion-col>\n  </ion-row>\n  <div class=\"separator ion-margin-vertical\"></div>\n  <ion-row>\n    <ion-col class=\"ion-no-padding\">\n      <ion-item lines=\"none\" class=\"ion-no-padding\">\n        <ion-text>You might all like</ion-text>\n        <ion-button\n          slot=\"end\"\n          fill=\"clear\"\n          size=\"small\"\n          shape=\"round\"\n          color=\"primary\"\n        >\n          See All\n        </ion-button>\n      </ion-item>\n\n      <ion-slides [options]=\"relatedConfig\">\n        <ion-slide *ngFor=\"let item of product.related\">\n          <app-product-card-sm [data]=\"item\"></app-product-card-sm>\n        </ion-slide>\n      </ion-slides>\n    </ion-col>\n  </ion-row> -->\n\n</ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/product-detail/product-detail-routing.module.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/pages/product-detail/product-detail-routing.module.ts ***!
    \***********************************************************************/

  /*! exports provided: ProductDetailPageRoutingModule */

  /***/
  function srcAppPagesProductDetailProductDetailRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProductDetailPageRoutingModule", function () {
      return ProductDetailPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _product_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./product-detail.page */
    "./src/app/pages/product-detail/product-detail.page.ts");

    var routes = [{
      path: '',
      component: _product_detail_page__WEBPACK_IMPORTED_MODULE_3__["ProductDetailPage"]
    }];

    var ProductDetailPageRoutingModule = function ProductDetailPageRoutingModule() {
      _classCallCheck(this, ProductDetailPageRoutingModule);
    };

    ProductDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ProductDetailPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/product-detail/product-detail.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/pages/product-detail/product-detail.module.ts ***!
    \***************************************************************/

  /*! exports provided: ProductDetailPageModule */

  /***/
  function srcAppPagesProductDetailProductDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProductDetailPageModule", function () {
      return ProductDetailPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _product_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./product-detail-routing.module */
    "./src/app/pages/product-detail/product-detail-routing.module.ts");
    /* harmony import */


    var _product_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./product-detail.page */
    "./src/app/pages/product-detail/product-detail.page.ts");
    /* harmony import */


    var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/components/components.module */
    "./src/app/components/components.module.ts");

    var ProductDetailPageModule = function ProductDetailPageModule() {
      _classCallCheck(this, ProductDetailPageModule);
    };

    ProductDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _product_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProductDetailPageRoutingModule"], src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]],
      declarations: [_product_detail_page__WEBPACK_IMPORTED_MODULE_6__["ProductDetailPage"]]
    })], ProductDetailPageModule);
    /***/
  },

  /***/
  "./src/app/pages/product-detail/product-detail.page.scss":
  /*!***************************************************************!*\
    !*** ./src/app/pages/product-detail/product-detail.page.scss ***!
    \***************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesProductDetailProductDetailPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".product-slides {\n  min-height: 330px;\n}\n\nion-avatar {\n  width: 40px;\n  height: 40px;\n}\n\nion-avatar .ava-img {\n  border: 1px solid rgba(228, 228, 228, 0.6);\n}\n\nion-card {\n  box-shadow: none !important;\n  min-height: 285px;\n}\n\n.prod-img {\n  width: 100%;\n  height: 275px;\n  background-color: #c4c4c4;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 10px;\n}\n\n.details span {\n  font-size: 13px;\n  color: var(--ion-color-medium);\n}\n\n.details h2 {\n  font-size: 19px;\n  margin: 0 10px 10px 10px !important;\n}\n\n.details p {\n  font-size: 17px;\n  margin: 0 !important;\n}\n\n.about {\n  font-weight: 300;\n  font-size: 15px;\n  line-height: 26px;\n  color: #151522;\n}\n\n.action-button {\n  --border-radius: 6px;\n  --box-shadow: none !important;\n  height: 48px;\n  margin: 20px 10px;\n}\n\n.action-button span {\n  font-weight: 300;\n  font-size: 16px;\n  line-height: 22px;\n  text-transform: initial;\n  color: #ffffff;\n}\n\n.separator {\n  width: 100%;\n  height: 1px;\n  background: rgba(228, 228, 228, 0.4);\n}\n\nion-text {\n  font-weight: 600;\n}\n\nion-item {\n  --inner-padding-end: 0;\n  --inner-padding-top: 0;\n  --inner-padding-bottom: 0;\n  --min-height: 34px;\n}\n\n.pick-container {\n  display: flex;\n  justify-content: space-between;\n  flex-direction: row;\n  align-items: center;\n}\n\n.item-container {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-evenly;\n  width: 100%;\n  padding-left: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcHJvZHVjdC1kZXRhaWwvQzpcXFVzZXJzXFxocFxcRGVza3RvcFxcaW9uaWNfcHJvamVjdHNcXEZpbmFsUHJvamVjdFxcc2hvcGlmeS9zcmNcXGFwcFxccGFnZXNcXHByb2R1Y3QtZGV0YWlsXFxwcm9kdWN0LWRldGFpbC5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3Byb2R1Y3QtZGV0YWlsL3Byb2R1Y3QtZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGlCQUFBO0FDQ0o7O0FERUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQ0NKOztBRENJO0VBQ0UsMENBQUE7QUNDTjs7QURHQTtFQUNJLDJCQUFBO0VBQ0EsaUJBQUE7QUNBSjs7QURHQTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0VBQ0EsbUJBQUE7QUNBSjs7QURJSTtFQUNJLGVBQUE7RUFDQSw4QkFBQTtBQ0RSOztBRElJO0VBQ0ksZUFBQTtFQUNBLG1DQUFBO0FDRlI7O0FES0k7RUFDSSxlQUFBO0VBQ0Esb0JBQUE7QUNIUjs7QURPQTtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQ0pKOztBRE9BO0VBQ0ksb0JBQUE7RUFDQSw2QkFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQ0pKOztBRE1JO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSx1QkFBQTtFQUNBLGNBQUE7QUNKTjs7QURRRTtFQUNFLFdBQUE7RUFDQSxXQUFBO0VBQ0Esb0NBQUE7QUNMSjs7QURRRTtFQUNJLGdCQUFBO0FDTE47O0FEUUU7RUFDRSxzQkFBQTtFQUNBLHNCQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBQ0xKOztBRFFFO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQ0xOOztBRFFFO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsNkJBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUNMTiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3Byb2R1Y3QtZGV0YWlsL3Byb2R1Y3QtZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wcm9kdWN0LXNsaWRlcyB7XG4gICAgbWluLWhlaWdodDogMzMwcHg7XG59XG5cbmlvbi1hdmF0YXIge1xuICAgIHdpZHRoOiA0MHB4O1xuICAgIGhlaWdodDogNDBweDtcbiAgXG4gICAgLmF2YS1pbWcge1xuICAgICAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyMjgsIDIyOCwgMjI4LCAwLjYpO1xuICAgIH1cbiAgfVxuXG5pb24tY2FyZCB7XG4gICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICAgIG1pbi1oZWlnaHQ6IDI4NXB4O1xufVxuXG4ucHJvZC1pbWcge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMjc1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgkY29sb3I6ICNjNGM0YzQsICRhbHBoYTogMS4wKTtcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuXG4uZGV0YWlscyB7XG4gICAgc3BhbiB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xuICAgIH1cblxuICAgIGgyIHtcbiAgICAgICAgZm9udC1zaXplOiAxOXB4O1xuICAgICAgICBtYXJnaW46IDAgMTBweCAxMHB4IDEwcHggIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICBwIHtcbiAgICAgICAgZm9udC1zaXplOiAxN3B4O1xuICAgICAgICBtYXJnaW46IDAgIWltcG9ydGFudDtcbiAgICB9XG59XG5cbi5hYm91dCB7XG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICBmb250LXNpemU6IDE1cHg7XG4gICAgbGluZS1oZWlnaHQ6IDI2cHg7XG4gICAgY29sb3I6ICMxNTE1MjI7XG59XG5cbi5hY3Rpb24tYnV0dG9uIHtcbiAgICAtLWJvcmRlci1yYWRpdXM6IDZweDtcbiAgICAtLWJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgICBoZWlnaHQ6IDQ4cHg7XG4gICAgbWFyZ2luOiAyMHB4IDEwcHg7XG4gIFxuICAgIHNwYW4ge1xuICAgICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICAgICAgdGV4dC10cmFuc2Zvcm06IGluaXRpYWw7XG4gICAgICBjb2xvcjogI2ZmZmZmZjtcbiAgICB9XG4gIH1cblxuICAuc2VwYXJhdG9yIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDFweDtcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDIyOCwgMjI4LCAyMjgsIDAuNDApO1xuICB9XG5cbiAgaW9uLXRleHQge1xuICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgfVxuXG4gIGlvbi1pdGVtIHtcbiAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwO1xuICAgIC0taW5uZXItcGFkZGluZy10b3A6IDA7XG4gICAgLS1pbm5lci1wYWRkaW5nLWJvdHRvbTogMDtcbiAgICAtLW1pbi1oZWlnaHQ6IDM0cHg7XG4gIH1cblxuICAucGljay1jb250YWluZXIge1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICB9XG5cbiAgLml0ZW0tY29udGFpbmVyIHtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1ldmVubHk7XG4gICAgICB3aWR0aDogMTAwJTtcbiAgICAgIHBhZGRpbmctbGVmdDogMjBweDtcbiAgfSIsIi5wcm9kdWN0LXNsaWRlcyB7XG4gIG1pbi1oZWlnaHQ6IDMzMHB4O1xufVxuXG5pb24tYXZhdGFyIHtcbiAgd2lkdGg6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbn1cbmlvbi1hdmF0YXIgLmF2YS1pbWcge1xuICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDIyOCwgMjI4LCAyMjgsIDAuNik7XG59XG5cbmlvbi1jYXJkIHtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICBtaW4taGVpZ2h0OiAyODVweDtcbn1cblxuLnByb2QtaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMjc1cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNjNGM0YzQ7XG4gIG9iamVjdC1maXQ6IGNvdmVyO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuXG4uZGV0YWlscyBzcGFuIHtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG59XG4uZGV0YWlscyBoMiB7XG4gIGZvbnQtc2l6ZTogMTlweDtcbiAgbWFyZ2luOiAwIDEwcHggMTBweCAxMHB4ICFpbXBvcnRhbnQ7XG59XG4uZGV0YWlscyBwIHtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBtYXJnaW46IDAgIWltcG9ydGFudDtcbn1cblxuLmFib3V0IHtcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBsaW5lLWhlaWdodDogMjZweDtcbiAgY29sb3I6ICMxNTE1MjI7XG59XG5cbi5hY3Rpb24tYnV0dG9uIHtcbiAgLS1ib3JkZXItcmFkaXVzOiA2cHg7XG4gIC0tYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDQ4cHg7XG4gIG1hcmdpbjogMjBweCAxMHB4O1xufVxuLmFjdGlvbi1idXR0b24gc3BhbiB7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbGluZS1oZWlnaHQ6IDIycHg7XG4gIHRleHQtdHJhbnNmb3JtOiBpbml0aWFsO1xuICBjb2xvcjogI2ZmZmZmZjtcbn1cblxuLnNlcGFyYXRvciB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDFweDtcbiAgYmFja2dyb3VuZDogcmdiYSgyMjgsIDIyOCwgMjI4LCAwLjQpO1xufVxuXG5pb24tdGV4dCB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5cbmlvbi1pdGVtIHtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLXRvcDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLWJvdHRvbTogMDtcbiAgLS1taW4taGVpZ2h0OiAzNHB4O1xufVxuXG4ucGljay1jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5pdGVtLWNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZy1sZWZ0OiAyMHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/product-detail/product-detail.page.ts":
  /*!*************************************************************!*\
    !*** ./src/app/pages/product-detail/product-detail.page.ts ***!
    \*************************************************************/

  /*! exports provided: ProductDetailPage */

  /***/
  function srcAppPagesProductDetailProductDetailPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProductDetailPage", function () {
      return ProductDetailPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _services_product_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../services/product.service */
    "./src/app/services/product.service.ts");
    /* harmony import */


    var _services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../services/user.service */
    "./src/app/services/user.service.ts");

    var ProductDetailPage = /*#__PURE__*/function () {
      function ProductDetailPage(productService, activatedRoute, userService) {
        _classCallCheck(this, ProductDetailPage);

        this.productService = productService;
        this.activatedRoute = activatedRoute;
        this.userService = userService;
        this.notOwner = true;
        this.currentUser = "";
        this.productUser = "";
        this.imgConfig = {
          spaceBetween: 3,
          slidesPerView: 1,
          centeredSlides: true
        };
        this.relatedConfig = {
          spaceBetween: 2,
          slidesPerView: 2
        };
        this.user = {};
        this.product = {};
        this.id = this.activatedRoute.snapshot.paramMap.get('id');
      }

      _createClass(ProductDetailPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          var _this = this;

          this.productService.getProduct(this.id).subscribe(function (result) {
            _this.product = result;
            _this.productUser = _this.product.user;

            _this.userService.getProfile().subscribe(function (result) {
              _this.user = result[0];
              _this.currentUser = _this.user.username;
              console.log(_this.currentUser);
              console.log(_this.productUser);

              if (_this.currentUser == _this.productUser) {
                console.log("You are owner");
                _this.notOwner = false;
              }
            });
          });
        }
      }]);

      return ProductDetailPage;
    }();

    ProductDetailPage.ctorParameters = function () {
      return [{
        type: _services_product_service__WEBPACK_IMPORTED_MODULE_3__["ProductService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"]
      }];
    };

    ProductDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-product-detail',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./product-detail.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/product-detail/product-detail.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./product-detail.page.scss */
      "./src/app/pages/product-detail/product-detail.page.scss"))["default"]]
    })], ProductDetailPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-product-detail-product-detail-module-es5.js.map