function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-forgot-pass-forgot-pass-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/forgot-pass/forgot-pass.page.html":
  /*!***********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/forgot-pass/forgot-pass.page.html ***!
    \***********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesForgotPassForgotPassPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\n\t<ion-toolbar>\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-back-button></ion-back-button>\n\t\t</ion-buttons>\n\t</ion-toolbar>\n</ion-header>\n\n\n<ion-content [fullscreen]=\"true\">\n  <ion-grid class=\"ion-padding-horizontal\">\n    <ion-row class=\"ion-padding-vertical\">\n      <ion-col size=\"8\" class=\"ion-padding-vertical\">\n        <h1 class=\"title\">Forgot Password?</h1>\n        <ion-text class=\"mb\"\n          >Enter your email to reset your password.</ion-text\n        >\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"ion-padding-top\">\n      <ion-col>\n        <form [formGroup]=\"resetForm\" (ngSubmit)=\"resetPass()\">\n          <ion-item lines=\"none\" class=\"ion-no-padding\">\n            <ion-label class=\"input-label\" position=\"stacked\"\n              >Email</ion-label\n            >\n            <ion-input\n              type=\"email\"\n              formControlName=\"email\"\n            ></ion-input>\n          </ion-item>\n          <div\n            class=\"errors-container\"\n            *ngIf=\"resetForm.get('email').invalid && (resetForm.get('email').dirty || resetForm.get('email').touched)\"\n          >\n            <ng-container *ngIf=\"resetForm.get('email').errors.required\"\n              >Email is required</ng-container\n            >\n            <ng-container *ngIf=\"resetForm.get('email').errors.invalidEmail\"\n              >Email is invalid</ng-container\n            >\n          </div>\n\n          <ion-button\n            [disabled]=\"resetForm.invalid\"\n            class=\"action-button ion-margin-top\"\n            expand=\"block\"\n            fill=\"solid\"\n            color=\"primary\"\n            type=\"submit\"\n          >\n            <span>Reset Password</span>\n          </ion-button>\n        </form>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/forgot-pass/forgot-pass-routing.module.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/pages/forgot-pass/forgot-pass-routing.module.ts ***!
    \*****************************************************************/

  /*! exports provided: ForgotPassPageRoutingModule */

  /***/
  function srcAppPagesForgotPassForgotPassRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ForgotPassPageRoutingModule", function () {
      return ForgotPassPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _forgot_pass_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./forgot-pass.page */
    "./src/app/pages/forgot-pass/forgot-pass.page.ts");

    var routes = [{
      path: '',
      component: _forgot_pass_page__WEBPACK_IMPORTED_MODULE_3__["ForgotPassPage"]
    }];

    var ForgotPassPageRoutingModule = function ForgotPassPageRoutingModule() {
      _classCallCheck(this, ForgotPassPageRoutingModule);
    };

    ForgotPassPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ForgotPassPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/forgot-pass/forgot-pass.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/pages/forgot-pass/forgot-pass.module.ts ***!
    \*********************************************************/

  /*! exports provided: ForgotPassPageModule */

  /***/
  function srcAppPagesForgotPassForgotPassModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ForgotPassPageModule", function () {
      return ForgotPassPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _forgot_pass_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./forgot-pass-routing.module */
    "./src/app/pages/forgot-pass/forgot-pass-routing.module.ts");
    /* harmony import */


    var _forgot_pass_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./forgot-pass.page */
    "./src/app/pages/forgot-pass/forgot-pass.page.ts");

    var ForgotPassPageModule = function ForgotPassPageModule() {
      _classCallCheck(this, ForgotPassPageModule);
    };

    ForgotPassPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _forgot_pass_routing_module__WEBPACK_IMPORTED_MODULE_5__["ForgotPassPageRoutingModule"]],
      declarations: [_forgot_pass_page__WEBPACK_IMPORTED_MODULE_6__["ForgotPassPage"]]
    })], ForgotPassPageModule);
    /***/
  },

  /***/
  "./src/app/pages/forgot-pass/forgot-pass.page.scss":
  /*!*********************************************************!*\
    !*** ./src/app/pages/forgot-pass/forgot-pass.page.scss ***!
    \*********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesForgotPassForgotPassPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header ion-toolbar {\n  --background: transparent;\n}\n\nh1.title {\n  font-weight: 600;\n  font-size: 28px;\n  line-height: 34px;\n  color: #151522;\n  padding: 0;\n  margin-bottom: 16px;\n}\n\nion-text {\n  font-weight: 300;\n  font-size: 17px;\n  line-height: 24px;\n  color: #151522;\n}\n\nion-item {\n  --background: transparent;\n  --inner-padding-end: 0;\n}\n\nion-item ion-input {\n  border: 1px solid rgba(228, 228, 228, 0.6);\n  box-sizing: border-box;\n  border-radius: 5px;\n  background: #ffffff;\n  --padding-start: 16px;\n  margin-bottom: 8px;\n  min-height: 48px;\n}\n\nion-item ion-toggle {\n  --background: rgba(153, 153, 153, 0.8);\n}\n\n.action-button {\n  --border-radius: 6px;\n  --box-shadow: none !important;\n  min-height: 48px;\n  box-shadow: 0px 4px 8px rgba(50, 50, 71, 0.06), 0px 4px 4px rgba(50, 50, 71, 0.08);\n}\n\n.action-button span {\n  font-weight: 300;\n  font-size: 16px;\n  line-height: 22px;\n  text-transform: initial;\n}\n\n.mb {\n  margin-bottom: 16px;\n}\n\n.link {\n  text-decoration: none !important;\n  font-weight: normal;\n  font-size: 15px;\n  line-height: 20px;\n}\n\n.input-label {\n  font-weight: 600;\n  color: #151522;\n  margin-bottom: 16px;\n}\n\n.caption {\n  color: #151522;\n}\n\n.errors-container {\n  font-size: 12px;\n  font-weight: 500;\n  color: var(--ion-color-danger);\n  margin-bottom: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZm9yZ290LXBhc3MvQzpcXFVzZXJzXFxocFxcRGVza3RvcFxcaW9uaWNfcHJvamVjdHNcXEZpbmFsUHJvamVjdFxcc2hvcGlmeS9zcmNcXGFwcFxccGFnZXNcXGZvcmdvdC1wYXNzXFxmb3Jnb3QtcGFzcy5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2ZvcmdvdC1wYXNzL2ZvcmdvdC1wYXNzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHlCQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVFO0VBQ0UseUJBQUE7RUFDQSxzQkFBQTtBQ0NKOztBRENJO0VBQ0UsMENBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNDTjs7QURFSTtFQUNFLHNDQUFBO0FDQU47O0FESUU7RUFDRSxvQkFBQTtFQUNBLDZCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrRkFBQTtBQ0RKOztBRElJO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSx1QkFBQTtBQ0ZOOztBRE1FO0VBQ0UsbUJBQUE7QUNISjs7QURNRTtFQUNFLGdDQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUNISjs7QURNRTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0FDSEo7O0FETUU7RUFDRSxjQUFBO0FDSEo7O0FETUU7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSw4QkFBQTtFQUNBLGtCQUFBO0FDSEoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9mb3Jnb3QtcGFzcy9mb3Jnb3QtcGFzcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIGlvbi10b29sYmFyIHtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICB9XG4gIFxuICBoMS50aXRsZSB7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXNpemU6IDI4cHg7XG4gICAgbGluZS1oZWlnaHQ6IDM0cHg7XG4gICAgY29sb3I6ICMxNTE1MjI7XG4gICAgcGFkZGluZzogMDtcbiAgICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICB9XG4gIFxuICBpb24tdGV4dCB7XG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICBmb250LXNpemU6IDE3cHg7XG4gICAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gICAgY29sb3I6ICMxNTE1MjI7XG4gIH1cbiAgXG4gIGlvbi1pdGVtIHtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XG4gIFxuICAgIGlvbi1pbnB1dCB7XG4gICAgICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDIyOCwgMjI4LCAyMjgsIDAuNik7XG4gICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgYmFja2dyb3VuZDogI2ZmZmZmZjtcbiAgICAgIC0tcGFkZGluZy1zdGFydDogMTZweDtcbiAgICAgIG1hcmdpbi1ib3R0b206IDhweDtcbiAgICAgIG1pbi1oZWlnaHQ6IDQ4cHg7XG4gICAgfVxuICBcbiAgICBpb24tdG9nZ2xlIHtcbiAgICAgIC0tYmFja2dyb3VuZDogcmdiYSgxNTMsIDE1MywgMTUzLCAwLjgpO1xuICAgIH1cbiAgfVxuICBcbiAgLmFjdGlvbi1idXR0b24ge1xuICAgIC0tYm9yZGVyLXJhZGl1czogNnB4O1xuICAgIC0tYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICAgIG1pbi1oZWlnaHQ6IDQ4cHg7XG4gICAgYm94LXNoYWRvdzogMHB4IDRweCA4cHggcmdiYSg1MCwgNTAsIDcxLCAwLjA2KSxcbiAgICAgIDBweCA0cHggNHB4IHJnYmEoNTAsIDUwLCA3MSwgMC4wOCk7XG4gIFxuICAgIHNwYW4ge1xuICAgICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICAgICAgdGV4dC10cmFuc2Zvcm06IGluaXRpYWw7XG4gICAgfVxuICB9XG4gIFxuICAubWIge1xuICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XG4gIH1cbiAgXG4gIC5saW5rIHtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmUgIWltcG9ydGFudDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICBsaW5lLWhlaWdodDogMjBweDtcbiAgfVxuICBcbiAgLmlucHV0LWxhYmVsIHtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGNvbG9yOiAjMTUxNTIyO1xuICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XG4gIH1cbiAgXG4gIC5jYXB0aW9uIHtcbiAgICBjb2xvcjogIzE1MTUyMjtcbiAgfVxuICBcbiAgLmVycm9ycy1jb250YWluZXIge1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyKTtcbiAgICBtYXJnaW4tYm90dG9tOiA4cHg7XG4gIH0iLCJpb24taGVhZGVyIGlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cblxuaDEudGl0bGUge1xuICBmb250LXdlaWdodDogNjAwO1xuICBmb250LXNpemU6IDI4cHg7XG4gIGxpbmUtaGVpZ2h0OiAzNHB4O1xuICBjb2xvcjogIzE1MTUyMjtcbiAgcGFkZGluZzogMDtcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcbn1cblxuaW9uLXRleHQge1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDE3cHg7XG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICBjb2xvcjogIzE1MTUyMjtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWlubmVyLXBhZGRpbmctZW5kOiAwO1xufVxuaW9uLWl0ZW0gaW9uLWlucHV0IHtcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyMjgsIDIyOCwgMjI4LCAwLjYpO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIGJhY2tncm91bmQ6ICNmZmZmZmY7XG4gIC0tcGFkZGluZy1zdGFydDogMTZweDtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xuICBtaW4taGVpZ2h0OiA0OHB4O1xufVxuaW9uLWl0ZW0gaW9uLXRvZ2dsZSB7XG4gIC0tYmFja2dyb3VuZDogcmdiYSgxNTMsIDE1MywgMTUzLCAwLjgpO1xufVxuXG4uYWN0aW9uLWJ1dHRvbiB7XG4gIC0tYm9yZGVyLXJhZGl1czogNnB4O1xuICAtLWJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgbWluLWhlaWdodDogNDhweDtcbiAgYm94LXNoYWRvdzogMHB4IDRweCA4cHggcmdiYSg1MCwgNTAsIDcxLCAwLjA2KSwgMHB4IDRweCA0cHggcmdiYSg1MCwgNTAsIDcxLCAwLjA4KTtcbn1cbi5hY3Rpb24tYnV0dG9uIHNwYW4ge1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICB0ZXh0LXRyYW5zZm9ybTogaW5pdGlhbDtcbn1cblxuLm1iIHtcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcbn1cblxuLmxpbmsge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmUgIWltcG9ydGFudDtcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBsaW5lLWhlaWdodDogMjBweDtcbn1cblxuLmlucHV0LWxhYmVsIHtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY29sb3I6ICMxNTE1MjI7XG4gIG1hcmdpbi1ib3R0b206IDE2cHg7XG59XG5cbi5jYXB0aW9uIHtcbiAgY29sb3I6ICMxNTE1MjI7XG59XG5cbi5lcnJvcnMtY29udGFpbmVyIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBmb250LXdlaWdodDogNTAwO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhbmdlcik7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/forgot-pass/forgot-pass.page.ts":
  /*!*******************************************************!*\
    !*** ./src/app/pages/forgot-pass/forgot-pass.page.ts ***!
    \*******************************************************/

  /*! exports provided: ForgotPassPage */

  /***/
  function srcAppPagesForgotPassForgotPassPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ForgotPassPage", function () {
      return ForgotPassPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var src_app_validators_email_validators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/validators/email.validators */
    "./src/app/validators/email.validators.ts");
    /* harmony import */


    var _services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../services/user.service */
    "./src/app/services/user.service.ts");

    var ForgotPassPage = /*#__PURE__*/function () {
      function ForgotPassPage(userService, formBuilder) {
        _classCallCheck(this, ForgotPassPage);

        this.userService = userService;
        this.formBuilder = formBuilder;
      }

      _createClass(ForgotPassPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.resetForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            'email': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, src_app_validators_email_validators__WEBPACK_IMPORTED_MODULE_3__["emailValidator"]])
          });
        }
      }, {
        key: "resetPass",
        value: function resetPass() {
          if (this.resetForm.valid) {
            console.log(this.resetForm.value);
            this.userService.forgotPass(this.resetForm.get('email').value);
          } else {
            console.log('Error');
          }
        }
      }]);

      return ForgotPassPage;
    }();

    ForgotPassPage.ctorParameters = function () {
      return [{
        type: _services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"]
      }, {
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }];
    };

    ForgotPassPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-forgot-pass',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./forgot-pass.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/forgot-pass/forgot-pass.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./forgot-pass.page.scss */
      "./src/app/pages/forgot-pass/forgot-pass.page.scss"))["default"]]
    })], ForgotPassPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-forgot-pass-forgot-pass-module-es5.js.map