function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-user-catalog-user-catalog-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/user-catalog/user-catalog.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/user-catalog/user-catalog.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesUserCatalogUserCatalogPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons> -->\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>Your Products</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\" class=\"ion-padding-horizontal\">\n  <ion-grid>\n    <ion-row class=\"ion-no-padding\">\n      <ion-col class=\"ion-padding-vertical\">\n        <ion-searchbar animated class=\"ion-no-padding\"></ion-searchbar>\n      </ion-col>\n    </ion-row>      \n    <ion-row>\n      <ion-col class=\"ion-no-padding\">\n        <ion-item lines=\"none\" class=\"section\">\n          <ion-text color=\"dark\">\n            <h5>{{ length }} Products</h5>\n          </ion-text>\n          <ion-buttons slot=\"end\">\n            <ion-button\n            slot=\"end\"\n            fill=\"clear\"\n            size=\"small\"\n            shape=\"round\"\n            color=\"medium\"\n            class=\"small-button\"\n            (click)=\"changeView('grid')\"\n          >\n            <ion-icon slot=\"icon-only\" name=\"grid-outline\"></ion-icon>\n          </ion-button>\n\n          <ion-button\n            slot=\"end\"\n            fill=\"clear\"\n            size=\"small\"\n            shape=\"round\"\n            color=\"medium\"\n            class=\"small-button\"\n            (click)=\"changeView('card')\"\n          >\n            <ion-icon slot=\"icon-only\" name=\"square-outline\"></ion-icon>\n          </ion-button>\n          </ion-buttons>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"ion-no-padding\">\n      <ng-container [ngSwitch]=\"layout\">\n        <ng-container *ngSwitchCase=\"'grid'\">\n          <ion-col size=\"6\" *ngFor=\"let product of products\" class=\"ion-no-padding\">\n            <app-product-card-sm [data]=\"product\" [routerLink]=\"['/user-details/', product.id]\"></app-product-card-sm>\n          </ion-col>\n        </ng-container>\n        <ng-container *ngSwitchCase=\"'card'\">\n          <ion-col  size=\"12\" *ngFor=\"let product of products\" class=\"ion-no-padding\">\n            <app-product-card-md [data]=\"product\" [routerLink]=\"['/user-details/', product.id]\"></app-product-card-md>\n          </ion-col>\n        </ng-container>\n        \n      </ng-container>\n\n    </ion-row>\n  </ion-grid>\n</ion-content>\n\n";
    /***/
  },

  /***/
  "./src/app/pages/user-catalog/user-catalog-routing.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/pages/user-catalog/user-catalog-routing.module.ts ***!
    \*******************************************************************/

  /*! exports provided: UserCatalogPageRoutingModule */

  /***/
  function srcAppPagesUserCatalogUserCatalogRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UserCatalogPageRoutingModule", function () {
      return UserCatalogPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _user_catalog_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./user-catalog.page */
    "./src/app/pages/user-catalog/user-catalog.page.ts");

    var routes = [{
      path: '',
      component: _user_catalog_page__WEBPACK_IMPORTED_MODULE_3__["UserCatalogPage"]
    }];

    var UserCatalogPageRoutingModule = function UserCatalogPageRoutingModule() {
      _classCallCheck(this, UserCatalogPageRoutingModule);
    };

    UserCatalogPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], UserCatalogPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/user-catalog/user-catalog.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/user-catalog/user-catalog.module.ts ***!
    \***********************************************************/

  /*! exports provided: UserCatalogPageModule */

  /***/
  function srcAppPagesUserCatalogUserCatalogModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UserCatalogPageModule", function () {
      return UserCatalogPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _user_catalog_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./user-catalog-routing.module */
    "./src/app/pages/user-catalog/user-catalog-routing.module.ts");
    /* harmony import */


    var _user_catalog_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./user-catalog.page */
    "./src/app/pages/user-catalog/user-catalog.page.ts");
    /* harmony import */


    var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/components/components.module */
    "./src/app/components/components.module.ts");

    var UserCatalogPageModule = function UserCatalogPageModule() {
      _classCallCheck(this, UserCatalogPageModule);
    };

    UserCatalogPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _user_catalog_routing_module__WEBPACK_IMPORTED_MODULE_5__["UserCatalogPageRoutingModule"], src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]],
      declarations: [_user_catalog_page__WEBPACK_IMPORTED_MODULE_6__["UserCatalogPage"]]
    })], UserCatalogPageModule);
    /***/
  },

  /***/
  "./src/app/pages/user-catalog/user-catalog.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/pages/user-catalog/user-catalog.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesUserCatalogUserCatalogPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-searchbar {\n  --box-shadow: 0 !important;\n  --border-radius: 8px;\n  --background: var(--ion-color-light);\n  --color: var(--ion-color-medium);\n}\n\n.section {\n  --padding-start: 0;\n  --inner-padding-end: 0;\n}\n\n.section h5 {\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdXNlci1jYXRhbG9nL0M6XFxVc2Vyc1xcaHBcXERlc2t0b3BcXGlvbmljX3Byb2plY3RzXFxGaW5hbFByb2plY3RcXHNob3BpZnkvc3JjXFxhcHBcXHBhZ2VzXFx1c2VyLWNhdGFsb2dcXHVzZXItY2F0YWxvZy5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3VzZXItY2F0YWxvZy91c2VyLWNhdGFsb2cucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksMEJBQUE7RUFDQSxvQkFBQTtFQUNBLG9DQUFBO0VBQ0EsZ0NBQUE7QUNDSjs7QURHQTtFQUNFLGtCQUFBO0VBQ0Esc0JBQUE7QUNBRjs7QURFRTtFQUNFLFNBQUE7QUNBSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3VzZXItY2F0YWxvZy91c2VyLWNhdGFsb2cucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXNlYXJjaGJhciB7XG4gICAgLS1ib3gtc2hhZG93OiAwICFpbXBvcnRhbnQ7XG4gICAgLS1ib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xufVxuXG5cbi5zZWN0aW9uIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICAtLWlubmVyLXBhZGRpbmctZW5kOiAwO1xuXG4gIGg1IHtcbiAgICBtYXJnaW46IDA7XG4gIH1cbn0iLCJpb24tc2VhcmNoYmFyIHtcbiAgLS1ib3gtc2hhZG93OiAwICFpbXBvcnRhbnQ7XG4gIC0tYm9yZGVyLXJhZGl1czogOHB4O1xuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG4gIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xufVxuXG4uc2VjdGlvbiB7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbn1cbi5zZWN0aW9uIGg1IHtcbiAgbWFyZ2luOiAwO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/user-catalog/user-catalog.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/pages/user-catalog/user-catalog.page.ts ***!
    \*********************************************************/

  /*! exports provided: UserCatalogPage */

  /***/
  function srcAppPagesUserCatalogUserCatalogPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UserCatalogPage", function () {
      return UserCatalogPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _services_product_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../../services/product.service */
    "./src/app/services/product.service.ts");

    var UserCatalogPage = /*#__PURE__*/function () {
      function UserCatalogPage(productService) {
        _classCallCheck(this, UserCatalogPage);

        this.productService = productService;
        this.layout = 'grid';
        this.products = [];
        this.length = 0;
      }

      _createClass(UserCatalogPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          var _this = this;

          this.productService.getUserProducts().subscribe(function (products) {
            _this.products = products;
            _this.length = _this.products.length;
          });
        }
      }, {
        key: "changeView",
        value: function changeView(param) {
          switch (param) {
            case 'grid':
              this.layout = 'grid';
              break;

            case 'card':
              this.layout = 'card';
              break;

            default:
              this.layout = 'grid';
              break;
          }
        }
      }]);

      return UserCatalogPage;
    }();

    UserCatalogPage.ctorParameters = function () {
      return [{
        type: _services_product_service__WEBPACK_IMPORTED_MODULE_2__["ProductService"]
      }];
    };

    UserCatalogPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-user-catalog',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./user-catalog.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/user-catalog/user-catalog.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./user-catalog.page.scss */
      "./src/app/pages/user-catalog/user-catalog.page.scss"))["default"]]
    })], UserCatalogPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-user-catalog-user-catalog-module-es5.js.map