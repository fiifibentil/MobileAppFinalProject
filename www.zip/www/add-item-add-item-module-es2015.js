(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-item-add-item-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-item/add-item.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-item/add-item.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-title>Create Product</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-grid class=\"ion-padding-horizontal\">\n    <ion-row>\n      <ion-col>\n        <form [formGroup]=\"productForm\" (ngSubmit)=\"submitProduct()\">\n          <ion-item>\n            <ion-label position=\"floating\" class=\"ion-no-padding\">Clothing Item Name <ion-text color=\"danger\">*</ion-text></ion-label>\n            <ion-input required formControlName=\"productName\" type=\"text\"></ion-input>\n          </ion-item>\n          <ion-item>\n            <ion-label position=\"floating\" class=\"ion-no-padding\">Price (GHC) <ion-text color=\"danger\">*</ion-text></ion-label>\n            <ion-input required formControlName=\"price\" type=\"number\"></ion-input>\n          </ion-item>\n          <ion-item>\n            <ion-select formControlName=\"chosenCat\" placeholder=\"Select Category\">\n              <ion-select-option *ngFor=\"let category of categories\" [value]=\"category.id\">{{category.title}}</ion-select-option>\n            </ion-select>\n          </ion-item>\n          <ion-item>\n            <ion-label position=\"floating\" class=\"ion-no-padding\">Description <ion-text color=\"danger\">*</ion-text></ion-label>\n            <ion-input required formControlName=\"description\" type=\"text\"></ion-input>\n          </ion-item>\n\n          <ion-item class=\"ion-no-padding\">\n            <ion-button (click)=\"chooseOrTakePicture()\" expand=\"block\" fill=\"clear\" shape=\"round\">\n              Choose Image\n            </ion-button>\n          </ion-item>\n          \n          <ion-button block color=\"primary\" type=\"submit\" [disabled]=\"productForm.invalid\">\n            Create Product\n          </ion-button>\n        </form>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/add-item/add-item-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/add-item/add-item-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: AddItemPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddItemPageRoutingModule", function() { return AddItemPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _add_item_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./add-item.page */ "./src/app/pages/add-item/add-item.page.ts");




const routes = [
    {
        path: '',
        component: _add_item_page__WEBPACK_IMPORTED_MODULE_3__["AddItemPage"]
    }
];
let AddItemPageRoutingModule = class AddItemPageRoutingModule {
};
AddItemPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AddItemPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/add-item/add-item.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/add-item/add-item.module.ts ***!
  \***************************************************/
/*! exports provided: AddItemPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddItemPageModule", function() { return AddItemPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _add_item_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./add-item-routing.module */ "./src/app/pages/add-item/add-item-routing.module.ts");
/* harmony import */ var _add_item_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-item.page */ "./src/app/pages/add-item/add-item.page.ts");







let AddItemPageModule = class AddItemPageModule {
};
AddItemPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _add_item_routing_module__WEBPACK_IMPORTED_MODULE_5__["AddItemPageRoutingModule"]
        ],
        declarations: [_add_item_page__WEBPACK_IMPORTED_MODULE_6__["AddItemPage"]]
    })
], AddItemPageModule);



/***/ }),

/***/ "./src/app/pages/add-item/add-item.page.scss":
/*!***************************************************!*\
  !*** ./src/app/pages/add-item/add-item.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-select {\n  width: 100%;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWRkLWl0ZW0vQzpcXFVzZXJzXFxocFxcRGVza3RvcFxcaW9uaWNfcHJvamVjdHNcXEZpbmFsUHJvamVjdFxcc2hvcGlmeS9zcmNcXGFwcFxccGFnZXNcXGFkZC1pdGVtXFxhZGQtaXRlbS5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2FkZC1pdGVtL2FkZC1pdGVtLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFFQSx1QkFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvYWRkLWl0ZW0vYWRkLWl0ZW0ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXNlbGVjdCB7XG4gICAgd2lkdGg6IDEwMCU7XG4gIFxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICB9IiwiaW9uLXNlbGVjdCB7XG4gIHdpZHRoOiAxMDAlO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/add-item/add-item.page.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/add-item/add-item.page.ts ***!
  \*************************************************/
/*! exports provided: AddItemPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddItemPage", function() { return AddItemPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/product.service */ "./src/app/services/product.service.ts");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");







const { Camera } = _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Plugins"];
let AddItemPage = class AddItemPage {
    constructor(productService, formBuilder, alertController, loadingController, plt, actionSheetController, router) {
        this.productService = productService;
        this.formBuilder = formBuilder;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.plt = plt;
        this.actionSheetController = actionSheetController;
        this.router = router;
        this.categories = [];
        this.formData = new FormData();
    }
    ngOnInit() {
        this.productForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            'productName': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, []),
            'price': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, []),
            'description': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, []),
            'chosenCat': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, []),
        });
    }
    ionViewWillEnter() {
        this.productService.getCategories().subscribe((categories) => {
            this.categories = categories;
        });
    }
    get productName() {
        return this.productForm.get('productName');
    }
    get price() {
        return this.productForm.get('price');
    }
    get description() {
        return this.productForm.get('description');
    }
    get category() {
        return this.productForm.get('chosenCat');
    }
    submitProduct() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.formData.append("title", this.productName.value);
            this.formData.append("price", this.price.value);
            this.formData.append("description", this.description.value);
            this.formData.append("category", this.category.value);
            const loading = yield this.loadingController.create();
            yield loading.present();
            this.productService.createProduct(this.formData).subscribe((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                const alert = yield this.alertController.create({
                    header: 'New Product Created',
                    message: 'Your product has been created',
                    buttons: [{
                            text: 'Ok',
                            handler: (data) => {
                            }
                        }],
                });
                yield alert.present();
                yield this.clearForm();
            }), (res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                const alert = yield this.alertController.create({
                    header: 'Product Creation Failed',
                    message: 'Failed to create product',
                    buttons: [{
                            text: 'Ok',
                            handler: (data) => {
                                console.log(data);
                                this.router.navigateByUrl('/tabs/add');
                            }
                        }],
                });
                yield alert.present();
            }));
        });
    }
    chooseOrTakePicture() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const image = yield _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Plugins"].Camera.getPhoto({
                quality: 90,
                allowEditing: false,
                width: 300,
                height: 300,
                resultType: _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["CameraResultType"].Base64,
            }).catch((error) => {
                console.log(error);
            });
            // variable image should contain our base64 image
            if (image) {
                // convert base64 image to blob
                let blob = this.b64toBlob(image.base64String);
                //Generate a fake filename
                let name = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 10);
                this.formData.append('image', blob, name + `.${image.format}`);
            }
        });
    }
    b64toBlob(b64Data, contentType = '', sliceSize = 512) {
        console.log(b64Data);
        const byteCharacters = atob(b64Data);
        const byteArrays = [];
        for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            const slice = byteCharacters.slice(offset, offset + sliceSize);
            const byteNumbers = new Array(slice.length);
            for (let i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
        }
        const blob = new Blob(byteArrays, { type: contentType });
        return blob;
    }
    clearForm() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.productForm.reset();
        });
    }
};
AddItemPage.ctorParameters = () => [
    { type: _services_product_service__WEBPACK_IMPORTED_MODULE_4__["ProductService"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] }
];
AddItemPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-add-item',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./add-item.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-item/add-item.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./add-item.page.scss */ "./src/app/pages/add-item/add-item.page.scss")).default]
    })
], AddItemPage);



/***/ })

}]);
//# sourceMappingURL=add-item-add-item-module-es2015.js.map