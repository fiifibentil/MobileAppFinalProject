(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["settings-three-settings-three-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/settings-three/settings-three.page.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/settings-three/settings-three.page.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-title>Profile</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\" class=\"ion-padding-vertical\">\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col class=\"ion-padding-horizontal ion-padding-bottom\">\n        <ion-item  lines=\"none\">\n          <ion-avatar slot=\"start\">\n              <img src=\"../../../assets/default_user.png\">\n          </ion-avatar>\n          <ion-label class=\"ion-no-margin\" *ngFor=\"let item of user | keyvalue\">\n            <h3>{{ item.value.username }}</h3>\n            <p>{{ item.value.email }}</p>\n          </ion-label>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"ion-no-padding\">\n      <ion-list>\n        <ion-item lines=\"none\" class=\"ion-padding-horizontal\" [routerLink]=\"['/user-catalog']\">\n            <ion-icon size=\"large\" slot=\"start\" [name]=\"cart-outline\"></ion-icon>\n          <ion-label>\n            <h2>My Items</h2>\n            <p>View Your Items</p>\n          </ion-label>\n          <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\n        </ion-item>\n\n        <ion-item lines=\"none\" class=\"ion-padding-horizontal\" [routerLink]=\"['/settings']\">\n            <ion-icon size=\"large\" slot=\"start\" [name]=\"settings-outline\"></ion-icon>\n          <ion-label>\n            <h2>Settings</h2>\n            <p>Customize your experience</p>\n          </ion-label>\n          <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\n        </ion-item>\n      </ion-list>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/settings-three/settings-three-routing.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/pages/settings-three/settings-three-routing.module.ts ***!
  \***********************************************************************/
/*! exports provided: SettingsThreePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsThreePageRoutingModule", function() { return SettingsThreePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _settings_three_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./settings-three.page */ "./src/app/pages/settings-three/settings-three.page.ts");




const routes = [
    {
        path: '',
        component: _settings_three_page__WEBPACK_IMPORTED_MODULE_3__["SettingsThreePage"]
    }
];
let SettingsThreePageRoutingModule = class SettingsThreePageRoutingModule {
};
SettingsThreePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SettingsThreePageRoutingModule);



/***/ }),

/***/ "./src/app/pages/settings-three/settings-three.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/settings-three/settings-three.module.ts ***!
  \***************************************************************/
/*! exports provided: SettingsThreePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsThreePageModule", function() { return SettingsThreePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _settings_three_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./settings-three-routing.module */ "./src/app/pages/settings-three/settings-three-routing.module.ts");
/* harmony import */ var _settings_three_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./settings-three.page */ "./src/app/pages/settings-three/settings-three.page.ts");







let SettingsThreePageModule = class SettingsThreePageModule {
};
SettingsThreePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _settings_three_routing_module__WEBPACK_IMPORTED_MODULE_5__["SettingsThreePageRoutingModule"]
        ],
        declarations: [_settings_three_page__WEBPACK_IMPORTED_MODULE_6__["SettingsThreePage"]]
    })
], SettingsThreePageModule);



/***/ }),

/***/ "./src/app/pages/settings-three/settings-three.page.scss":
/*!***************************************************************!*\
  !*** ./src/app/pages/settings-three/settings-three.page.scss ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-avatar {\n  width: 60px;\n  height: 60px;\n}\nion-avatar img {\n  border: 1px solid rgba(228, 228, 228, 0.6);\n}\nh3 {\n  font-weight: normal;\n  font-size: 20px;\n  line-height: 25px;\n}\np {\n  font-weight: 300;\n  font-size: 15px;\n  line-height: 20px;\n}\nion-list {\n  width: 100%;\n}\nion-list ion-item {\n  --inner-padding-end: 0;\n  border-bottom: 1px solid rgba(228, 228, 228, 0.6);\n}\nion-list ion-item ion-icon[slot=start] {\n  color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2V0dGluZ3MtdGhyZWUvQzpcXFVzZXJzXFxocFxcRGVza3RvcFxcaW9uaWNfcHJvamVjdHNcXEZpbmFsUHJvamVjdFxcc2hvcGlmeS9zcmNcXGFwcFxccGFnZXNcXHNldHRpbmdzLXRocmVlXFxzZXR0aW5ncy10aHJlZS5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3NldHRpbmdzLXRocmVlL3NldHRpbmdzLXRocmVlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FDQ0Y7QURDRTtFQUNFLDBDQUFBO0FDQ0o7QURHQTtFQUNFLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FDQUY7QURHQTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FDQUY7QURHQTtFQUNFLFdBQUE7QUNBRjtBREVFO0VBQ0Usc0JBQUE7RUFDQSxpREFBQTtBQ0FKO0FERUk7RUFDRSwrQkFBQTtBQ0FOIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvc2V0dGluZ3MtdGhyZWUvc2V0dGluZ3MtdGhyZWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWF2YXRhciB7XG4gIHdpZHRoOiA2MHB4O1xuICBoZWlnaHQ6IDYwcHg7XG5cbiAgaW1nIHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDIyOCwgMjI4LCAyMjgsIDAuNik7XG4gIH1cbn1cblxuaDMge1xuICBmb250LXdlaWdodDogbm9ybWFsO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGxpbmUtaGVpZ2h0OiAyNXB4O1xufVxuXG5wIHtcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBsaW5lLWhlaWdodDogMjBweDtcbn1cblxuaW9uLWxpc3Qge1xuICB3aWR0aDogMTAwJTtcblxuICBpb24taXRlbSB7XG4gICAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgcmdiYSgyMjgsIDIyOCwgMjI4LCAwLjYpO1xuXG4gICAgaW9uLWljb25bc2xvdD1cInN0YXJ0XCJdIHtcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgfVxuICB9XG59XG4iLCJpb24tYXZhdGFyIHtcbiAgd2lkdGg6IDYwcHg7XG4gIGhlaWdodDogNjBweDtcbn1cbmlvbi1hdmF0YXIgaW1nIHtcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyMjgsIDIyOCwgMjI4LCAwLjYpO1xufVxuXG5oMyB7XG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbGluZS1oZWlnaHQ6IDI1cHg7XG59XG5cbnAge1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDE1cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMHB4O1xufVxuXG5pb24tbGlzdCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuaW9uLWxpc3QgaW9uLWl0ZW0ge1xuICAtLWlubmVyLXBhZGRpbmctZW5kOiAwO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgcmdiYSgyMjgsIDIyOCwgMjI4LCAwLjYpO1xufVxuaW9uLWxpc3QgaW9uLWl0ZW0gaW9uLWljb25bc2xvdD1zdGFydF0ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/settings-three/settings-three.page.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/settings-three/settings-three.page.ts ***!
  \*************************************************************/
/*! exports provided: SettingsThreePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsThreePage", function() { return SettingsThreePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/user.service */ "./src/app/services/user.service.ts");



let SettingsThreePage = class SettingsThreePage {
    constructor(userService) {
        this.userService = userService;
        this.user = {};
        this.menu = [
            {
                icon: 'cart-outline',
                title: 'My Items',
                subtitle: 'View your items',
            },
            {
                icon: 'cash-outline',
                title: 'Transactions',
                subtitle: 'View incoming/ outgoing transactions',
            },
            {
                icon: 'send-outline',
                title: 'Messages',
                subtitle: 'Chat with other users',
            },
            {
                icon: 'settings-outline',
                title: 'Settings',
                subtitle: 'Customize your app experience',
            },
        ];
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.userService.getProfile().subscribe(result => {
            this.user = result;
            console.log(this.user);
        });
    }
};
SettingsThreePage.ctorParameters = () => [
    { type: _services_user_service__WEBPACK_IMPORTED_MODULE_2__["UserService"] }
];
SettingsThreePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-settings-three',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./settings-three.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/settings-three/settings-three.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./settings-three.page.scss */ "./src/app/pages/settings-three/settings-three.page.scss")).default]
    })
], SettingsThreePage);



/***/ })

}]);
//# sourceMappingURL=settings-three-settings-three-module-es2015.js.map