(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-login-three-login-three-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login-three/login-three.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login-three/login-three.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons> -->\n  </ion-toolbar>\n</ion-header>\n<ion-content [fullscreen]=\"true\">\n  <ion-grid class=\"ion-padding-horizontal\">\n    <ion-row class=\"ion-padding-vertical\">\n      <ion-col size=\"8\" class=\"ion-padding-vertical\">\n        <h1 class=\"title\">Welcome Back</h1>\n        <ion-text class=\"mb\"\n          >Enter your email and password for signing in.</ion-text\n        >\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"ion-padding-top\">\n      <ion-col>\n        <form [formGroup]=\"loginForm\" (ngSubmit)=\"login()\">\n          <ion-item lines=\"none\" class=\"ion-no-padding\">\n            <ion-label class=\"input-label\" position=\"stacked\"\n              >Username</ion-label\n            >\n            <ion-input\n              type=\"text\"\n              formControlName=\"username\"\n            ></ion-input>\n          </ion-item>\n          <div\n            class=\"errors-container\"\n            *ngIf=\"loginForm.get('username').invalid && (loginForm.get('username').dirty || loginForm.get('username').touched)\"\n          >\n            <ng-container *ngIf=\"loginForm.get('username').errors.required\"\n              >Username is required</ng-container\n            >\n            <ng-container *ngIf=\"loginForm.get('username').errors.invalidEmail\"\n              >Username is invalid</ng-container\n            >\n          </div>\n          <ion-item lines=\"none\" class=\"ion-no-padding\">\n            <ion-label class=\"input-label\" position=\"stacked\"\n              >Password</ion-label\n            >\n            <ion-input\n              type=\"password\"\n              formControlName=\"password\"\n            ></ion-input>\n          </ion-item>\n          <div\n            class=\"errors-container\"\n            *ngIf=\"loginForm.get('password').invalid && (loginForm.get('password').dirty || loginForm.get('password').touched)\"\n          >\n            <ng-container *ngIf=\"loginForm.get('password').errors.required\">\n              Password is required\n            </ng-container>\n            <ng-container *ngIf=\"loginForm.get('password').errors.invalidPassword\">\n              {{loginForm.get('password').errors.message}}\n            </ng-container>\n          </div>\n\n          <ion-button\n            [disabled]=\"loginForm.invalid\"\n            class=\"action-button ion-margin-top\"\n            expand=\"block\"\n            fill=\"solid\"\n            color=\"primary\"\n            type=\"submit\"\n          >\n            <span>Sign In</span>\n          </ion-button>\n        </form>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col class=\"ion-text-center ion-padding-bottom\">\n        <a class=\"link\" [routerLink]=\"['/register']\">Need an account?</a>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col class=\"ion-text-center ion-padding-bottom\">\n        <a class=\"link\" [routerLink]=\"['/forgot-pass']\">Forgot password?</a>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/login-three/login-three-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/login-three/login-three-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: LoginThreePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginThreePageRoutingModule", function() { return LoginThreePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _login_three_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login-three.page */ "./src/app/pages/login-three/login-three.page.ts");




const routes = [
    {
        path: '',
        component: _login_three_page__WEBPACK_IMPORTED_MODULE_3__["LoginThreePage"]
    }
];
let LoginThreePageRoutingModule = class LoginThreePageRoutingModule {
};
LoginThreePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LoginThreePageRoutingModule);



/***/ }),

/***/ "./src/app/pages/login-three/login-three.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/login-three/login-three.module.ts ***!
  \*********************************************************/
/*! exports provided: LoginThreePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginThreePageModule", function() { return LoginThreePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _login_three_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login-three-routing.module */ "./src/app/pages/login-three/login-three-routing.module.ts");
/* harmony import */ var _login_three_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login-three.page */ "./src/app/pages/login-three/login-three.page.ts");







let LoginThreePageModule = class LoginThreePageModule {
};
LoginThreePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _login_three_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginThreePageRoutingModule"]
        ],
        declarations: [_login_three_page__WEBPACK_IMPORTED_MODULE_6__["LoginThreePage"]]
    })
], LoginThreePageModule);



/***/ }),

/***/ "./src/app/pages/login-three/login-three.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/login-three/login-three.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-toolbar {\n  --background: transparent;\n}\n\nh1.title {\n  font-weight: 600;\n  font-size: 28px;\n  line-height: 34px;\n  color: #151522;\n  padding: 0;\n  margin-bottom: 16px;\n}\n\nion-text {\n  font-weight: 300;\n  font-size: 17px;\n  line-height: 24px;\n  color: #151522;\n}\n\nion-item {\n  --background: transparent;\n  --inner-padding-end: 0;\n}\n\nion-item ion-input {\n  border: 1px solid rgba(228, 228, 228, 0.6);\n  box-sizing: border-box;\n  border-radius: 5px;\n  background: #ffffff;\n  --padding-start: 16px;\n  margin-bottom: 8px;\n  min-height: 48px;\n}\n\nion-item ion-toggle {\n  --background: rgba(153, 153, 153, 0.8);\n}\n\n.action-button {\n  --border-radius: 6px;\n  --box-shadow: none !important;\n  min-height: 48px;\n  box-shadow: 0px 4px 8px rgba(50, 50, 71, 0.06), 0px 4px 4px rgba(50, 50, 71, 0.08);\n}\n\n.action-button span {\n  font-weight: 300;\n  font-size: 16px;\n  line-height: 22px;\n  text-transform: initial;\n}\n\n.mb {\n  margin-bottom: 16px;\n}\n\n.link {\n  text-decoration: none !important;\n  font-weight: normal;\n  font-size: 15px;\n  line-height: 20px;\n}\n\n.input-label {\n  font-weight: 600;\n  color: #151522;\n  margin-bottom: 16px;\n}\n\n.caption {\n  color: #151522;\n}\n\n.errors-container {\n  font-size: 12px;\n  font-weight: 500;\n  color: var(--ion-color-danger);\n  margin-bottom: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbG9naW4tdGhyZWUvQzpcXFVzZXJzXFxocFxcRGVza3RvcFxcaW9uaWNfcHJvamVjdHNcXEZpbmFsUHJvamVjdFxcc2hvcGlmeS9zcmNcXGFwcFxccGFnZXNcXGxvZ2luLXRocmVlXFxsb2dpbi10aHJlZS5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2xvZ2luLXRocmVlL2xvZ2luLXRocmVlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQ0NGOztBREVBO0VBQ0UseUJBQUE7RUFDQSxzQkFBQTtBQ0NGOztBRENFO0VBQ0UsMENBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNDSjs7QURFRTtFQUNFLHNDQUFBO0FDQUo7O0FESUE7RUFDRSxvQkFBQTtFQUNBLDZCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrRkFBQTtBQ0RGOztBRElFO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSx1QkFBQTtBQ0ZKOztBRE1BO0VBQ0UsbUJBQUE7QUNIRjs7QURNQTtFQUNFLGdDQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUNIRjs7QURNQTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0FDSEY7O0FETUE7RUFDRSxjQUFBO0FDSEY7O0FETUE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSw4QkFBQTtFQUNBLGtCQUFBO0FDSEYiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9sb2dpbi10aHJlZS9sb2dpbi10aHJlZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIGlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cblxuaDEudGl0bGUge1xuICBmb250LXdlaWdodDogNjAwO1xuICBmb250LXNpemU6IDI4cHg7XG4gIGxpbmUtaGVpZ2h0OiAzNHB4O1xuICBjb2xvcjogIzE1MTUyMjtcbiAgcGFkZGluZzogMDtcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcbn1cblxuaW9uLXRleHQge1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDE3cHg7XG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICBjb2xvcjogIzE1MTUyMjtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWlubmVyLXBhZGRpbmctZW5kOiAwO1xuXG4gIGlvbi1pbnB1dCB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyMjgsIDIyOCwgMjI4LCAwLjYpO1xuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgIGJhY2tncm91bmQ6ICNmZmZmZmY7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xuICAgIG1hcmdpbi1ib3R0b206IDhweDtcbiAgICBtaW4taGVpZ2h0OiA0OHB4O1xuICB9XG5cbiAgaW9uLXRvZ2dsZSB7XG4gICAgLS1iYWNrZ3JvdW5kOiByZ2JhKDE1MywgMTUzLCAxNTMsIDAuOCk7XG4gIH1cbn1cblxuLmFjdGlvbi1idXR0b24ge1xuICAtLWJvcmRlci1yYWRpdXM6IDZweDtcbiAgLS1ib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG4gIG1pbi1oZWlnaHQ6IDQ4cHg7XG4gIGJveC1zaGFkb3c6IDBweCA0cHggOHB4IHJnYmEoNTAsIDUwLCA3MSwgMC4wNiksXG4gICAgMHB4IDRweCA0cHggcmdiYSg1MCwgNTAsIDcxLCAwLjA4KTtcblxuICBzcGFuIHtcbiAgICBmb250LXdlaWdodDogMzAwO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBsaW5lLWhlaWdodDogMjJweDtcbiAgICB0ZXh0LXRyYW5zZm9ybTogaW5pdGlhbDtcbiAgfVxufVxuXG4ubWIge1xuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xufVxuXG4ubGluayB7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZSAhaW1wb3J0YW50O1xuICBmb250LXdlaWdodDogbm9ybWFsO1xuICBmb250LXNpemU6IDE1cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMHB4O1xufVxuXG4uaW5wdXQtbGFiZWwge1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogIzE1MTUyMjtcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcbn1cblxuLmNhcHRpb24ge1xuICBjb2xvcjogIzE1MTUyMjtcbn1cblxuLmVycm9ycy1jb250YWluZXIge1xuICBmb250LXNpemU6IDEycHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyKTtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufSIsImlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuXG5oMS50aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGZvbnQtc2l6ZTogMjhweDtcbiAgbGluZS1oZWlnaHQ6IDM0cHg7XG4gIGNvbG9yOiAjMTUxNTIyO1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xufVxuXG5pb24tdGV4dCB7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gIGNvbG9yOiAjMTUxNTIyO1xufVxuXG5pb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XG59XG5pb24taXRlbSBpb24taW5wdXQge1xuICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDIyOCwgMjI4LCAyMjgsIDAuNik7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgYmFja2dyb3VuZDogI2ZmZmZmZjtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xuICBtYXJnaW4tYm90dG9tOiA4cHg7XG4gIG1pbi1oZWlnaHQ6IDQ4cHg7XG59XG5pb24taXRlbSBpb24tdG9nZ2xlIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKDE1MywgMTUzLCAxNTMsIDAuOCk7XG59XG5cbi5hY3Rpb24tYnV0dG9uIHtcbiAgLS1ib3JkZXItcmFkaXVzOiA2cHg7XG4gIC0tYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICBtaW4taGVpZ2h0OiA0OHB4O1xuICBib3gtc2hhZG93OiAwcHggNHB4IDhweCByZ2JhKDUwLCA1MCwgNzEsIDAuMDYpLCAwcHggNHB4IDRweCByZ2JhKDUwLCA1MCwgNzEsIDAuMDgpO1xufVxuLmFjdGlvbi1idXR0b24gc3BhbiB7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbGluZS1oZWlnaHQ6IDIycHg7XG4gIHRleHQtdHJhbnNmb3JtOiBpbml0aWFsO1xufVxuXG4ubWIge1xuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xufVxuXG4ubGluayB7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZSAhaW1wb3J0YW50O1xuICBmb250LXdlaWdodDogbm9ybWFsO1xuICBmb250LXNpemU6IDE1cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMHB4O1xufVxuXG4uaW5wdXQtbGFiZWwge1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogIzE1MTUyMjtcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcbn1cblxuLmNhcHRpb24ge1xuICBjb2xvcjogIzE1MTUyMjtcbn1cblxuLmVycm9ycy1jb250YWluZXIge1xuICBmb250LXNpemU6IDEycHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyKTtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/login-three/login-three.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/login-three/login-three.page.ts ***!
  \*******************************************************/
/*! exports provided: LoginThreePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginThreePage", function() { return LoginThreePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/user.service */ "./src/app/services/user.service.ts");






let LoginThreePage = class LoginThreePage {
    constructor(alertController, userService, formBuilder, router, loadingController) {
        this.alertController = alertController;
        this.userService = userService;
        this.formBuilder = formBuilder;
        this.router = router;
        this.loadingController = loadingController;
    }
    ngOnInit() {
        this.loginForm = this.formBuilder.group({
            username: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]],
            password: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]],
        });
    }
    login() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create();
            yield loading.present();
            this.userService.loginUser(this.username.value, this.password.value).subscribe((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                this.router.navigateByUrl('/tabs/home', { replaceUrl: true });
            }), (res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                const alert = yield this.alertController.create({
                    header: 'Login failed',
                    message: JSON.parse(JSON.stringify(res.error)).non_field_errors,
                    buttons: ['OK'],
                });
                yield alert.present();
            }));
        });
    }
    get username() {
        return this.loginForm.get('username');
    }
    get password() {
        return this.loginForm.get('password');
    }
};
LoginThreePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _services_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] }
];
LoginThreePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-login-three',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./login-three.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login-three/login-three.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./login-three.page.scss */ "./src/app/pages/login-three/login-three.page.scss")).default]
    })
], LoginThreePage);



/***/ })

}]);
//# sourceMappingURL=pages-login-three-login-three-module-es2015.js.map