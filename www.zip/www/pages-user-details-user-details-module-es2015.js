(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-user-details-user-details-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/user-details/user-details.page.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/user-details/user-details.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons> -->\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>Product Detail</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\" class=\"ion-padding-horizontal\">\n<ion-grid>\n  <ion-row>\n    <ion-col class=\"ion-no-padding\">\n      <ion-slides pager=\"true\" [options]=\"imgConfig\" class=\"product-slides\">\n        <ion-slide>\n          <ion-card>\n            <ion-card-content class=\"ion-no-padding\">\n              <img class=\"prod-img\" src=\"{{ product.image }}\" alt=\"\" />\n            </ion-card-content>\n          </ion-card>\n        </ion-slide>\n      </ion-slides>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col class=\"ion-no-padding\">\n      <div class=\"details ion-text-center\">\n        <!-- <span>{{ product.category }}</span> -->\n        <h2> {{ product.title }}</h2>\n        <p>{{ product.price | currency }}</p>\n\n        <ion-button\n        class=\"action-button\"\n        expand=\"block\"\n        fill=\"solid\"\n        color=\"primary\"\n        type=\"button\"\n        [routerLink]=\"['/edit-product', id]\"\n      >\n        <span>Edit</span>\n      </ion-button>\n      <ion-button\n      class=\"action-button\"\n      expand=\"block\"\n      fill=\"solid\"\n      color=\"danger\"\n      type=\"button\"\n      (click)=\"deleteProduct()\"\n    >\n      <span>Delete</span>\n    </ion-button>\n      </div>\n    </ion-col>\n  </ion-row>\n  <!-- <div class=\"separator ion-margin-vertical\"></div> -->\n  <!-- <ion-row>\n    <ion-col>\n      <div class=\"pick-container\">\n        <div>\n          <ion-text>Color</ion-text>\n        </div>\n        <div class=\"item-container\">\n          <app-product-color *ngFor=\"let item of product.colors\"\n          [color]=\"item.code\"></app-product-color>\n        </div>\n      </div>\n    </ion-col>\n  </ion-row> -->\n  <!-- <div class=\"separator ion-margin-vertical\"></div>\n  <ion-row>\n    <ion-col>\n      <div class=\"pick-container\">\n        <div>\n          <ion-text>Size</ion-text>\n        </div>\n        <div class=\"item-container\">\n          <app-product-size *ngFor=\"let item of product.sizes\"\n          [size]=\"item\"></app-product-size>\n        </div>\n      </div>\n    </ion-col>\n  </ion-row> -->\n  <div class=\"separator ion-margin-vertical\"></div>\n  <ion-row>\n    <ion-col>\n      <ion-text>About</ion-text>\n      <p class=\"about\">{{ product.description }}</p>\n    </ion-col>\n  </ion-row>\n  <div class=\"separator ion-margin-vertical\"></div>\n  <!--<ion-row>\n    <ion-col class=\"ion-no-padding\">\n      <ion-item lines=\"none\" class=\"ion-no-padding\">\n        <ion-text>Overall Score</ion-text>\n        <ion-button\n          slot=\"end\"\n          fill=\"clear\"\n          size=\"small\"\n          shape=\"round\"\n          color=\"primary\"\n        >\n          See All\n        </ion-button>\n      </ion-item>\n      <app-review-counter [data]=\"product.reviews\"></app-review-counter>\n    </ion-col>\n  </ion-row>\n  <div class=\"separator ion-margin-vertical\"></div>\n  <ion-row>\n    <ion-col class=\"ion-no-padding\">\n      <ion-item lines=\"none\" class=\"ion-no-padding\">\n        <ion-text>You might all like</ion-text>\n        <ion-button\n          slot=\"end\"\n          fill=\"clear\"\n          size=\"small\"\n          shape=\"round\"\n          color=\"primary\"\n        >\n          See All\n        </ion-button>\n      </ion-item>\n\n      <ion-slides [options]=\"relatedConfig\">\n        <ion-slide *ngFor=\"let item of product.related\">\n          <app-product-card-sm [data]=\"item\"></app-product-card-sm>\n        </ion-slide>\n      </ion-slides>\n    </ion-col>\n  </ion-row> -->\n\n</ion-grid>\n</ion-content>\n\n");

/***/ }),

/***/ "./src/app/pages/user-details/user-details-routing.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/user-details/user-details-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: UserDetailsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserDetailsPageRoutingModule", function() { return UserDetailsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _user_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./user-details.page */ "./src/app/pages/user-details/user-details.page.ts");




const routes = [
    {
        path: '',
        component: _user_details_page__WEBPACK_IMPORTED_MODULE_3__["UserDetailsPage"]
    }
];
let UserDetailsPageRoutingModule = class UserDetailsPageRoutingModule {
};
UserDetailsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], UserDetailsPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/user-details/user-details.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/user-details/user-details.module.ts ***!
  \***********************************************************/
/*! exports provided: UserDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserDetailsPageModule", function() { return UserDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _user_details_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./user-details-routing.module */ "./src/app/pages/user-details/user-details-routing.module.ts");
/* harmony import */ var _user_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./user-details.page */ "./src/app/pages/user-details/user-details.page.ts");
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/components.module */ "./src/app/components/components.module.ts");








let UserDetailsPageModule = class UserDetailsPageModule {
};
UserDetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _user_details_routing_module__WEBPACK_IMPORTED_MODULE_5__["UserDetailsPageRoutingModule"],
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]
        ],
        declarations: [_user_details_page__WEBPACK_IMPORTED_MODULE_6__["UserDetailsPage"]]
    })
], UserDetailsPageModule);



/***/ }),

/***/ "./src/app/pages/user-details/user-details.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/pages/user-details/user-details.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".product-slides {\n  min-height: 330px;\n}\n\nion-avatar {\n  width: 40px;\n  height: 40px;\n}\n\nion-avatar .ava-img {\n  border: 1px solid rgba(228, 228, 228, 0.6);\n}\n\nion-card {\n  box-shadow: none !important;\n  min-height: 285px;\n}\n\n.prod-img {\n  width: 100%;\n  height: 275px;\n  background-color: #c4c4c4;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 10px;\n}\n\n.details span {\n  font-size: 13px;\n  color: var(--ion-color-medium);\n}\n\n.details h2 {\n  font-size: 19px;\n  margin: 0 10px 10px 10px !important;\n}\n\n.details p {\n  font-size: 17px;\n  margin: 0 !important;\n}\n\n.about {\n  font-weight: 300;\n  font-size: 15px;\n  line-height: 26px;\n  color: #151522;\n}\n\n.action-button {\n  --border-radius: 6px;\n  --box-shadow: none !important;\n  height: 48px;\n  margin: 20px 10px;\n}\n\n.action-button span {\n  font-weight: 300;\n  font-size: 16px;\n  line-height: 22px;\n  text-transform: initial;\n  color: #ffffff;\n}\n\n.separator {\n  width: 100%;\n  height: 1px;\n  background: rgba(228, 228, 228, 0.4);\n}\n\nion-text {\n  font-weight: 600;\n}\n\nion-item {\n  --inner-padding-end: 0;\n  --inner-padding-top: 0;\n  --inner-padding-bottom: 0;\n  --min-height: 34px;\n}\n\n.pick-container {\n  display: flex;\n  justify-content: space-between;\n  flex-direction: row;\n  align-items: center;\n}\n\n.item-container {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-evenly;\n  width: 100%;\n  padding-left: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdXNlci1kZXRhaWxzL0M6XFxVc2Vyc1xcaHBcXERlc2t0b3BcXGlvbmljX3Byb2plY3RzXFxGaW5hbFByb2plY3RcXHNob3BpZnkvc3JjXFxhcHBcXHBhZ2VzXFx1c2VyLWRldGFpbHNcXHVzZXItZGV0YWlscy5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3VzZXItZGV0YWlscy91c2VyLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksaUJBQUE7QUNDSjs7QURFQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0FDQ0o7O0FEQ0k7RUFDRSwwQ0FBQTtBQ0NOOztBREdBO0VBQ0ksMkJBQUE7RUFDQSxpQkFBQTtBQ0FKOztBREdBO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7RUFDQSxtQkFBQTtBQ0FKOztBRElJO0VBQ0ksZUFBQTtFQUNBLDhCQUFBO0FDRFI7O0FESUk7RUFDSSxlQUFBO0VBQ0EsbUNBQUE7QUNGUjs7QURLSTtFQUNJLGVBQUE7RUFDQSxvQkFBQTtBQ0hSOztBRE9BO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FDSko7O0FET0E7RUFDSSxvQkFBQTtFQUNBLDZCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FDSko7O0FETUk7RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLHVCQUFBO0VBQ0EsY0FBQTtBQ0pOOztBRFFFO0VBQ0UsV0FBQTtFQUNBLFdBQUE7RUFDQSxvQ0FBQTtBQ0xKOztBRFFFO0VBQ0ksZ0JBQUE7QUNMTjs7QURRRTtFQUNFLHNCQUFBO0VBQ0Esc0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0FDTEo7O0FEUUU7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0FDTE47O0FEUUU7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSw2QkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQ0xOIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvdXNlci1kZXRhaWxzL3VzZXItZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucHJvZHVjdC1zbGlkZXMge1xuICAgIG1pbi1oZWlnaHQ6IDMzMHB4O1xufVxuXG5pb24tYXZhdGFyIHtcbiAgICB3aWR0aDogNDBweDtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gIFxuICAgIC5hdmEtaW1nIHtcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoMjI4LCAyMjgsIDIyOCwgMC42KTtcbiAgICB9XG4gIH1cblxuaW9uLWNhcmQge1xuICAgIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgICBtaW4taGVpZ2h0OiAyODVweDtcbn1cblxuLnByb2QtaW1nIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDI3NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoJGNvbG9yOiAjYzRjNGM0LCAkYWxwaGE6IDEuMCk7XG4gICAgb2JqZWN0LWZpdDogY292ZXI7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cblxuLmRldGFpbHMge1xuICAgIHNwYW4ge1xuICAgICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbiAgICB9XG5cbiAgICBoMiB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTlweDtcbiAgICAgICAgbWFyZ2luOiAwIDEwcHggMTBweCAxMHB4ICFpbXBvcnRhbnQ7XG4gICAgfVxuXG4gICAgcCB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTdweDtcbiAgICAgICAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XG4gICAgfVxufVxuXG4uYWJvdXQge1xuICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgZm9udC1zaXplOiAxNXB4O1xuICAgIGxpbmUtaGVpZ2h0OiAyNnB4O1xuICAgIGNvbG9yOiAjMTUxNTIyO1xufVxuXG4uYWN0aW9uLWJ1dHRvbiB7XG4gICAgLS1ib3JkZXItcmFkaXVzOiA2cHg7XG4gICAgLS1ib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG4gICAgaGVpZ2h0OiA0OHB4O1xuICAgIG1hcmdpbjogMjBweCAxMHB4O1xuICBcbiAgICBzcGFuIHtcbiAgICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICBsaW5lLWhlaWdodDogMjJweDtcbiAgICAgIHRleHQtdHJhbnNmb3JtOiBpbml0aWFsO1xuICAgICAgY29sb3I6ICNmZmZmZmY7XG4gICAgfVxuICB9XG5cbiAgLnNlcGFyYXRvciB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxcHg7XG4gICAgYmFja2dyb3VuZDogcmdiYSgyMjgsIDIyOCwgMjI4LCAwLjQwKTtcbiAgfVxuXG4gIGlvbi10ZXh0IHtcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIH1cblxuICBpb24taXRlbSB7XG4gICAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbiAgICAtLWlubmVyLXBhZGRpbmctdG9wOiAwO1xuICAgIC0taW5uZXItcGFkZGluZy1ib3R0b206IDA7XG4gICAgLS1taW4taGVpZ2h0OiAzNHB4O1xuICB9XG5cbiAgLnBpY2stY29udGFpbmVyIHtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgfVxuXG4gIC5pdGVtLWNvbnRhaW5lciB7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIH0iLCIucHJvZHVjdC1zbGlkZXMge1xuICBtaW4taGVpZ2h0OiAzMzBweDtcbn1cblxuaW9uLWF2YXRhciB7XG4gIHdpZHRoOiA0MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG59XG5pb24tYXZhdGFyIC5hdmEtaW1nIHtcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyMjgsIDIyOCwgMjI4LCAwLjYpO1xufVxuXG5pb24tY2FyZCB7XG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgbWluLWhlaWdodDogMjg1cHg7XG59XG5cbi5wcm9kLWltZyB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDI3NXB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYzRjNGM0O1xuICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cblxuLmRldGFpbHMgc3BhbiB7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xufVxuLmRldGFpbHMgaDIge1xuICBmb250LXNpemU6IDE5cHg7XG4gIG1hcmdpbjogMCAxMHB4IDEwcHggMTBweCAhaW1wb3J0YW50O1xufVxuLmRldGFpbHMgcCB7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XG59XG5cbi5hYm91dCB7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbGluZS1oZWlnaHQ6IDI2cHg7XG4gIGNvbG9yOiAjMTUxNTIyO1xufVxuXG4uYWN0aW9uLWJ1dHRvbiB7XG4gIC0tYm9yZGVyLXJhZGl1czogNnB4O1xuICAtLWJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBtYXJnaW46IDIwcHggMTBweDtcbn1cbi5hY3Rpb24tYnV0dG9uIHNwYW4ge1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICB0ZXh0LXRyYW5zZm9ybTogaW5pdGlhbDtcbiAgY29sb3I6ICNmZmZmZmY7XG59XG5cbi5zZXBhcmF0b3Ige1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxcHg7XG4gIGJhY2tncm91bmQ6IHJnYmEoMjI4LCAyMjgsIDIyOCwgMC40KTtcbn1cblxuaW9uLXRleHQge1xuICBmb250LXdlaWdodDogNjAwO1xufVxuXG5pb24taXRlbSB7XG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XG4gIC0taW5uZXItcGFkZGluZy10b3A6IDA7XG4gIC0taW5uZXItcGFkZGluZy1ib3R0b206IDA7XG4gIC0tbWluLWhlaWdodDogMzRweDtcbn1cblxuLnBpY2stY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uaXRlbS1jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmctbGVmdDogMjBweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/user-details/user-details.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/user-details/user-details.page.ts ***!
  \*********************************************************/
/*! exports provided: UserDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserDetailsPage", function() { return UserDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/product.service */ "./src/app/services/product.service.ts");





let UserDetailsPage = class UserDetailsPage {
    constructor(productService, activatedRoute, router, alertController, loadingController) {
        this.productService = productService;
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.imgConfig = {
            spaceBetween: 3,
            slidesPerView: 1,
            centeredSlides: true
        };
        this.relatedConfig = {
            spaceBetween: 2,
            slidesPerView: 2,
        };
        this.product = {};
        this.id = this.activatedRoute.snapshot.paramMap.get('id');
    }
    ionViewWillEnter() {
        this.productService.getProduct(this.id).subscribe(result => {
            this.product = result;
        });
    }
    ngOnInit() {
    }
    deleteProduct() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Danger!',
                message: 'Do you want to delete this product?',
                buttons: ['Cancel', { text: 'OK', handler: (e) => this.confirmDelete() }]
            });
            yield alert.present();
        });
    }
    confirmDelete() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create();
            yield loading.present();
            this.productService.deleteUserProducts(this.product.id).subscribe((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                const alert = yield this.alertController.create({
                    header: 'Deleted',
                    message: 'Your product has been deleted.',
                    buttons: ['OK'],
                });
                yield alert.present();
                this.router.navigateByUrl('/user-catalog');
            }), (res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                // show all values in the error object...map
                const alert = yield this.alertController.create({
                    header: 'Delete failed',
                    message: 'Failed to delete product',
                    buttons: ['OK'],
                });
                yield alert.present();
            }));
        });
    }
};
UserDetailsPage.ctorParameters = () => [
    { type: _services_product_service__WEBPACK_IMPORTED_MODULE_4__["ProductService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] }
];
UserDetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-user-details',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./user-details.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/user-details/user-details.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./user-details.page.scss */ "./src/app/pages/user-details/user-details.page.scss")).default]
    })
], UserDetailsPage);



/***/ })

}]);
//# sourceMappingURL=pages-user-details-user-details-module-es2015.js.map