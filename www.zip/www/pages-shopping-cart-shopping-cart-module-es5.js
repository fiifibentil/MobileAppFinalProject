function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-shopping-cart-shopping-cart-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/shopping-cart/shopping-cart.page.html":
  /*!***************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/shopping-cart/shopping-cart.page.html ***!
    \***************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesShoppingCartShoppingCartPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>Shopping Cart</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\" class=\"ion-padding-horizontal\">\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <p class=\"section ion-padding-bottom\">Selected Item</p>\n        <ion-list>\n          <ion-item>\n            <app-shopping-cart-item\n              [image]=\"selected.image\"\n              [name]=\"selected.title\"\n              [price]=\"selected.price\"\n            >\n            </app-shopping-cart-item>\n          </ion-item>\n        </ion-list>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col>\n        <p class=\"section ion-padding-bottom\">Payment Method</p>\n        <ion-list>\n          <ion-item>\n            <app-shopping-cart-item\n              [image]=\"paymentMethod.image\"\n              [name]=\"paymentMethod.title\"\n              [price]=\"paymentMethod.price\"\n            >\n            </app-shopping-cart-item>\n            <ion-button (click)=\"choosePaymentMethod()\" expand=\"block\" fill=\"clear\" shape=\"round\" color=\"primary\" slot=\"end\">\n              Change\n            </ion-button>\n          </ion-item>\n        </ion-list>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col>\n        <p class=\"section ion-padding-bottom\">Summary</p>\n        <!-- <small>Do you have a promo code?</small>\n        <form [formGroup]=\"couponForm\" (ngSubmit)=\"applyCode()\">\n          <ion-item lines=\"none\" class=\"input-container ion-no-padding\">\n            <ion-input\n              type=\"text\"\n              class=\"ion-no-padding\"\n              formControlName=\"coupon\"\n            ></ion-input>\n            <ion-button\n              slot=\"end\"\n              class=\"coupon-button\"\n              color=\"light\"\n              type=\"submit\"\n            >\n              <span>Apply</span>\n            </ion-button>\n          </ion-item>\n        </form> -->\n        <ion-list>\n          <ion-item lines=\"none\" class=\"invoice-item\">\n            <ion-label>Subtotal</ion-label>\n            <ion-text slot=\"end\">{{ subTotal | currency }}</ion-text>\n          </ion-item>\n\n          <ion-item *ngIf=\"balance\" lines=\"none\" class=\"invoice-item\">\n            <ion-label>Balance</ion-label>\n            <ion-text slot=\"end\">{{ balance | currency }}</ion-text>\n          </ion-item>\n          \n          <!-- <ion-item lines=\"none\" class=\"invoice-item\">\n            <ion-label>Shipping</ion-label>\n            <ion-text slot=\"end\">{{ order.shipping | currency }}</ion-text>\n          </ion-item> -->\n          <!-- <ion-item lines=\"none\" class=\"invoice-item\">\n            <ion-label>Tax</ion-label>\n            <ion-text slot=\"end\">({{ order.tax }}%) {{ order.taxAmount | currency }}</ion-text>\n          </ion-item> -->\n        </ion-list>\n        <div class=\"separator\"></div>\n        <ion-item lines=\"none\" class=\"invoice-total\">\n          <ion-label>Total</ion-label>\n          <ion-text slot=\"end\">{{ total | currency }}</ion-text>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col>\n        <!-- <ion-button\n          class=\"action-button\"\n          expand=\"block\"\n          fill=\"solid\"\n          color=\"primary\"\n          type=\"button\"\n        >\n          <span>Offer Trade</span>\n        </ion-button> -->\n\n        <angular4-paystack\n          [email]=\"'adorkorj@gmail.com'\"\n          [currency]=\"'GHS'\"\n          [amount]=\"total * 100\"\n          [ref]=\"reference\"\n          [channels]=\"['card', 'mobile_money']\"\n          [class]=\"'btn btn-primary'\"\n          (close)=\"paymentCancel()\"\n          (callback)=\"paymentDone($event)\"\n        >\n        <ion-button\n        class=\"action-button\"\n        expand=\"block\"\n        fill=\"solid\"\n        color=\"primary\"\n        type=\"button\"\n      >\n        <span>Purchase</span>\n      </ion-button>\n        </angular4-paystack>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/shopping-cart/shopping-cart-routing.module.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/pages/shopping-cart/shopping-cart-routing.module.ts ***!
    \*********************************************************************/

  /*! exports provided: ShoppingCartPageRoutingModule */

  /***/
  function srcAppPagesShoppingCartShoppingCartRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ShoppingCartPageRoutingModule", function () {
      return ShoppingCartPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _shopping_cart_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./shopping-cart.page */
    "./src/app/pages/shopping-cart/shopping-cart.page.ts");

    var routes = [{
      path: '',
      component: _shopping_cart_page__WEBPACK_IMPORTED_MODULE_3__["ShoppingCartPage"]
    }];

    var ShoppingCartPageRoutingModule = function ShoppingCartPageRoutingModule() {
      _classCallCheck(this, ShoppingCartPageRoutingModule);
    };

    ShoppingCartPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ShoppingCartPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/shopping-cart/shopping-cart.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/pages/shopping-cart/shopping-cart.module.ts ***!
    \*************************************************************/

  /*! exports provided: ShoppingCartPageModule */

  /***/
  function srcAppPagesShoppingCartShoppingCartModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ShoppingCartPageModule", function () {
      return ShoppingCartPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _shopping_cart_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./shopping-cart-routing.module */
    "./src/app/pages/shopping-cart/shopping-cart-routing.module.ts");
    /* harmony import */


    var _shopping_cart_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./shopping-cart.page */
    "./src/app/pages/shopping-cart/shopping-cart.page.ts");
    /* harmony import */


    var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/components/components.module */
    "./src/app/components/components.module.ts");
    /* harmony import */


    var angular4_paystack__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! angular4-paystack */
    "./node_modules/angular4-paystack/__ivy_ngcc__/fesm2015/angular4-paystack.js");

    var ShoppingCartPageModule = function ShoppingCartPageModule() {
      _classCallCheck(this, ShoppingCartPageModule);
    };

    ShoppingCartPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _shopping_cart_routing_module__WEBPACK_IMPORTED_MODULE_5__["ShoppingCartPageRoutingModule"], src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"], angular4_paystack__WEBPACK_IMPORTED_MODULE_8__["Angular4PaystackModule"].forRoot('pk_test_f6096b2cf6577c0741535bde96177c80513ffc3a')],
      declarations: [_shopping_cart_page__WEBPACK_IMPORTED_MODULE_6__["ShoppingCartPage"]],
      schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })], ShoppingCartPageModule);
    /***/
  },

  /***/
  "./src/app/pages/shopping-cart/shopping-cart.page.scss":
  /*!*************************************************************!*\
    !*** ./src/app/pages/shopping-cart/shopping-cart.page.scss ***!
    \*************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesShoppingCartShoppingCartPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".action-button {\n  --border-radius: 6px;\n  --box-shadow: none !important;\n  height: 48px;\n  margin: 20px 10px;\n}\n.action-button span {\n  font-weight: 300;\n  font-size: 16px;\n  line-height: 22px;\n  text-transform: initial;\n  color: #ffffff;\n}\n.separator {\n  width: 100%;\n  height: 1px;\n  background: rgba(228, 228, 228, 0.4);\n}\n.section {\n  font-weight: 600;\n  margin: 0 !important;\n}\nion-item-option {\n  background: none;\n}\n.notif-button {\n  --border-radius: 50%;\n  margin-left: 0;\n  margin-right: 0;\n  margin-top: 0;\n  margin-bottom: 0;\n  width: 48px;\n  height: 48px;\n}\n.item-options-ios {\n  border-bottom-style: none;\n}\n.ios > .notif-button {\n  width: auto !important;\n  height: auto !important;\n  --padding-start: 0;\n  --padding-end: 0;\n}\n.input-container {\n  --background: transparent;\n  --inner-padding-end: 0;\n  margin-top: 16px;\n}\n.input-container ion-input {\n  border: 1px solid rgba(228, 228, 228, 0.6);\n  box-sizing: border-box;\n  border-radius: 5px;\n  background: #ffffff;\n  --padding-start: 16px;\n  min-height: 46px;\n}\n.coupon-button {\n  height: 46px;\n  margin: 0 0 0 6px;\n  --border-radius: 6px;\n  --box-shadow: none !important;\n}\n.coupon-button span {\n  padding: 0 12px;\n}\n.separator {\n  width: 100%;\n  height: 1px;\n  background: rgba(228, 228, 228, 0.4);\n}\n.invoice-item {\n  --inner-padding-end: 0;\n  --inner-padding-top: 0;\n  --inner-padding-bottom: 0;\n  --padding-start: 0 !important;\n  --min-height: 32px;\n}\n.invoice-item ion-label {\n  margin: 0 !important;\n  text-align: left;\n  font-size: 13px;\n}\n.invoice-item ion-text {\n  font-size: 13px;\n}\n.invoice-total {\n  --inner-padding-end: 0;\n  --inner-padding-top: 0;\n  --inner-padding-bottom: 0;\n  --padding-start: 0 !important;\n  --min-height: 32px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2hvcHBpbmctY2FydC9DOlxcVXNlcnNcXGhwXFxEZXNrdG9wXFxpb25pY19wcm9qZWN0c1xcRmluYWxQcm9qZWN0XFxzaG9waWZ5L3NyY1xcYXBwXFxwYWdlc1xcc2hvcHBpbmctY2FydFxcc2hvcHBpbmctY2FydC5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3Nob3BwaW5nLWNhcnQvc2hvcHBpbmctY2FydC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQkFBQTtFQUNBLDZCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FDQ0Y7QURDRTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxjQUFBO0FDQ0o7QURHQTtFQUNFLFdBQUE7RUFDQSxXQUFBO0VBQ0Esb0NBQUE7QUNBRjtBREdBO0VBQ0UsZ0JBQUE7RUFDQSxvQkFBQTtBQ0FGO0FESUE7RUFDRSxnQkFBQTtBQ0RGO0FESUE7RUFDRSxvQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNERjtBRElBO0VBQ0UseUJBQUE7QUNERjtBRElBO0VBQ0Usc0JBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNERjtBRElBO0VBQ0UseUJBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0FDREY7QURHRTtFQUNFLDBDQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EscUJBQUE7RUFDQSxnQkFBQTtBQ0RKO0FES0E7RUFDRSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtFQUNBLDZCQUFBO0FDRkY7QURJRTtFQUNFLGVBQUE7QUNGSjtBRE9BO0VBQ0UsV0FBQTtFQUNBLFdBQUE7RUFDQSxvQ0FBQTtBQ0pGO0FET0E7RUFDRSxzQkFBQTtFQUNBLHNCQUFBO0VBQ0EseUJBQUE7RUFDQSw2QkFBQTtFQUNBLGtCQUFBO0FDSkY7QURNRTtFQUNFLG9CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FDSko7QURPRTtFQUNFLGVBQUE7QUNMSjtBRFVBO0VBQ0Usc0JBQUE7RUFDQSxzQkFBQTtFQUNBLHlCQUFBO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtBQ1BGIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvc2hvcHBpbmctY2FydC9zaG9wcGluZy1jYXJ0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5hY3Rpb24tYnV0dG9uIHtcbiAgLS1ib3JkZXItcmFkaXVzOiA2cHg7XG4gIC0tYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDQ4cHg7XG4gIG1hcmdpbjogMjBweCAxMHB4O1xuXG4gIHNwYW4ge1xuICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICAgIHRleHQtdHJhbnNmb3JtOiBpbml0aWFsO1xuICAgIGNvbG9yOiAjZmZmZmZmO1xuICB9XG59XG5cbi5zZXBhcmF0b3Ige1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxcHg7XG4gIGJhY2tncm91bmQ6IHJnYmEoMjI4LCAyMjgsIDIyOCwgMC40KTtcbn1cblxuLnNlY3Rpb24ge1xuICBmb250LXdlaWdodDogNjAwO1xuICBtYXJnaW46IDAgIWltcG9ydGFudDtcbn1cblxuXG5pb24taXRlbS1vcHRpb24ge1xuICBiYWNrZ3JvdW5kOiBub25lO1xufVxuXG4ubm90aWYtYnV0dG9uIHtcbiAgLS1ib3JkZXItcmFkaXVzOiA1MCU7XG4gIG1hcmdpbi1sZWZ0OiAwO1xuICBtYXJnaW4tcmlnaHQ6IDA7XG4gIG1hcmdpbi10b3A6IDA7XG4gIG1hcmdpbi1ib3R0b206IDA7XG4gIHdpZHRoOiA0OHB4O1xuICBoZWlnaHQ6IDQ4cHg7XG59XG5cbi5pdGVtLW9wdGlvbnMtaW9zICB7XG4gIGJvcmRlci1ib3R0b20tc3R5bGU6IG5vbmU7XG59XG5cbi5pb3MgPiAubm90aWYtYnV0dG9uIHtcbiAgd2lkdGg6IGF1dG8gIWltcG9ydGFudDtcbiAgaGVpZ2h0OiBhdXRvICFpbXBvcnRhbnQ7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbiAgLS1wYWRkaW5nLWVuZDogMDtcbn1cblxuLmlucHV0LWNvbnRhaW5lciB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XG4gIG1hcmdpbi10b3A6IDE2cHg7XG5cbiAgaW9uLWlucHV0IHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDIyOCwgMjI4LCAyMjgsIDAuNik7XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgYmFja2dyb3VuZDogI2ZmZmZmZjtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDE2cHg7XG4gICAgbWluLWhlaWdodDogNDZweDtcbiAgfVxufVxuXG4uY291cG9uLWJ1dHRvbiB7XG4gIGhlaWdodDogNDZweDtcbiAgbWFyZ2luOiAwIDAgMCA2cHg7XG4gIC0tYm9yZGVyLXJhZGl1czogNnB4O1xuICAtLWJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcblxuICBzcGFuIHtcbiAgICBwYWRkaW5nOiAwIDEycHg7XG4gIH1cbn1cblxuXG4uc2VwYXJhdG9yIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMXB4O1xuICBiYWNrZ3JvdW5kOiByZ2JhKDIyOCwgMjI4LCAyMjgsIDAuNDApO1xufVxuXG4uaW52b2ljZS1pdGVtIHtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLXRvcDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLWJvdHRvbTogMDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwICFpbXBvcnRhbnQ7XG4gIC0tbWluLWhlaWdodDogMzJweDtcblxuICBpb24tbGFiZWwge1xuICAgIG1hcmdpbjogMCAhaW1wb3J0YW50O1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgZm9udC1zaXplOiAxM3B4O1xuICB9XG5cbiAgaW9uLXRleHQge1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgfVxufVxuXG5cbi5pbnZvaWNlLXRvdGFsIHtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLXRvcDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLWJvdHRvbTogMDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwICFpbXBvcnRhbnQ7XG4gIC0tbWluLWhlaWdodDogMzJweDtcbn0iLCIuYWN0aW9uLWJ1dHRvbiB7XG4gIC0tYm9yZGVyLXJhZGl1czogNnB4O1xuICAtLWJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBtYXJnaW46IDIwcHggMTBweDtcbn1cbi5hY3Rpb24tYnV0dG9uIHNwYW4ge1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICB0ZXh0LXRyYW5zZm9ybTogaW5pdGlhbDtcbiAgY29sb3I6ICNmZmZmZmY7XG59XG5cbi5zZXBhcmF0b3Ige1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxcHg7XG4gIGJhY2tncm91bmQ6IHJnYmEoMjI4LCAyMjgsIDIyOCwgMC40KTtcbn1cblxuLnNlY3Rpb24ge1xuICBmb250LXdlaWdodDogNjAwO1xuICBtYXJnaW46IDAgIWltcG9ydGFudDtcbn1cblxuaW9uLWl0ZW0tb3B0aW9uIHtcbiAgYmFja2dyb3VuZDogbm9uZTtcbn1cblxuLm5vdGlmLWJ1dHRvbiB7XG4gIC0tYm9yZGVyLXJhZGl1czogNTAlO1xuICBtYXJnaW4tbGVmdDogMDtcbiAgbWFyZ2luLXJpZ2h0OiAwO1xuICBtYXJnaW4tdG9wOiAwO1xuICBtYXJnaW4tYm90dG9tOiAwO1xuICB3aWR0aDogNDhweDtcbiAgaGVpZ2h0OiA0OHB4O1xufVxuXG4uaXRlbS1vcHRpb25zLWlvcyB7XG4gIGJvcmRlci1ib3R0b20tc3R5bGU6IG5vbmU7XG59XG5cbi5pb3MgPiAubm90aWYtYnV0dG9uIHtcbiAgd2lkdGg6IGF1dG8gIWltcG9ydGFudDtcbiAgaGVpZ2h0OiBhdXRvICFpbXBvcnRhbnQ7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbiAgLS1wYWRkaW5nLWVuZDogMDtcbn1cblxuLmlucHV0LWNvbnRhaW5lciB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XG4gIG1hcmdpbi10b3A6IDE2cHg7XG59XG4uaW5wdXQtY29udGFpbmVyIGlvbi1pbnB1dCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoMjI4LCAyMjgsIDIyOCwgMC42KTtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBiYWNrZ3JvdW5kOiAjZmZmZmZmO1xuICAtLXBhZGRpbmctc3RhcnQ6IDE2cHg7XG4gIG1pbi1oZWlnaHQ6IDQ2cHg7XG59XG5cbi5jb3Vwb24tYnV0dG9uIHtcbiAgaGVpZ2h0OiA0NnB4O1xuICBtYXJnaW46IDAgMCAwIDZweDtcbiAgLS1ib3JkZXItcmFkaXVzOiA2cHg7XG4gIC0tYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xufVxuLmNvdXBvbi1idXR0b24gc3BhbiB7XG4gIHBhZGRpbmc6IDAgMTJweDtcbn1cblxuLnNlcGFyYXRvciB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDFweDtcbiAgYmFja2dyb3VuZDogcmdiYSgyMjgsIDIyOCwgMjI4LCAwLjQpO1xufVxuXG4uaW52b2ljZS1pdGVtIHtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLXRvcDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLWJvdHRvbTogMDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwICFpbXBvcnRhbnQ7XG4gIC0tbWluLWhlaWdodDogMzJweDtcbn1cbi5pbnZvaWNlLWl0ZW0gaW9uLWxhYmVsIHtcbiAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGZvbnQtc2l6ZTogMTNweDtcbn1cbi5pbnZvaWNlLWl0ZW0gaW9uLXRleHQge1xuICBmb250LXNpemU6IDEzcHg7XG59XG5cbi5pbnZvaWNlLXRvdGFsIHtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLXRvcDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLWJvdHRvbTogMDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwICFpbXBvcnRhbnQ7XG4gIC0tbWluLWhlaWdodDogMzJweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/shopping-cart/shopping-cart.page.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/shopping-cart/shopping-cart.page.ts ***!
    \***********************************************************/

  /*! exports provided: ShoppingCartPage */

  /***/
  function srcAppPagesShoppingCartShoppingCartPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ShoppingCartPage", function () {
      return ShoppingCartPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _services_product_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../services/product.service */
    "./src/app/services/product.service.ts");

    var ShoppingCartPage = /*#__PURE__*/function () {
      function ShoppingCartPage(fb, alertController, productService, activatedRoute, router) {
        _classCallCheck(this, ShoppingCartPage);

        this.fb = fb;
        this.alertController = alertController;
        this.productService = productService;
        this.activatedRoute = activatedRoute;
        this.router = router; // default to pay with cash on launch
        // create vars that dynamically populate payment method scr...

        this.selected = {};
        this.paymentMethod = {};
        this.products = [];
        this.subTotal = 0;
        this.balance = 0;
        this.total = 0;
        this.order = {};
        this.reference = 0;
        this.reference = Math.floor(Math.random() * 1000000000 + 1);
      }

      _createClass(ShoppingCartPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          var _this = this;

          this.paymentMethod = {
            title: "Pay with Cash",
            price: null,
            image: "../../../assets/cash.png"
          };
          this.id = this.activatedRoute.snapshot.paramMap.get('id');
          this.productService.getProduct(this.id).subscribe(function (result) {
            _this.selected = result;
            _this.subTotal = result.price;
            _this.total = result.price;
          });
          this.productService.getUserProducts().subscribe(function (products) {
            _this.products = products;
          });
          this.calcTotal();
        }
      }, {
        key: "calcTotal",
        value: function calcTotal() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this2 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    if (!this.paymentMethod.price) {
                      _context.next = 10;
                      break;
                    }

                    if (this.paymentMethod.price <= this.subTotal) {
                      this.balance = this.subTotal - this.paymentMethod.price;
                      this.total = this.balance;
                    }

                    if (!(this.paymentMethod.price > this.subTotal)) {
                      _context.next = 8;
                      break;
                    }

                    _context.next = 5;
                    return this.alertController.create({
                      header: 'Error',
                      message: 'Please choose an item of equal or lesser value',
                      buttons: [{
                        text: 'OK',
                        handler: function handler(data) {
                          _this2.chooseProduct();
                        }
                      }]
                    });

                  case 5:
                    alert = _context.sent;
                    _context.next = 8;
                    return alert.present();

                  case 8:
                    _context.next = 11;
                    break;

                  case 10:
                    this.total = this.subTotal;

                  case 11:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "calcInvoice",
        value: function calcInvoice(order) {
          var subTotal = 0;
          var total = 0;
          subTotal = order.items.reduce(function (acc, value) {
            return acc + value.price;
          }, 0);
          total = subTotal + order.taxAmount + order.shipping;
          Object.assign(order, {
            subTotal: subTotal
          }, {
            total: total
          });
        }
      }, {
        key: "applyCode",
        value: function applyCode() {
          if (this.couponForm.valid) {// do something
          } else {// do smething
            }
        }
      }, {
        key: "choosePaymentMethod",
        value: function choosePaymentMethod() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this3 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.alertController.create({
                      cssClass: 'my-custom-class',
                      header: 'Payment Method',
                      inputs: [{
                        name: 'method',
                        type: 'radio',
                        label: 'Pay with Cash',
                        value: 'cash',
                        handler: function handler() {
                          console.log('Pay with Cash');
                        },
                        checked: true
                      }, {
                        name: 'method',
                        type: 'radio',
                        label: 'Direct Trade',
                        value: 'trade',
                        handler: function handler() {
                          console.log('Direct Trade');
                        }
                      }],
                      buttons: [{
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler() {
                          console.log('Confirm Cancel');
                        }
                      }, {
                        text: 'Ok',
                        handler: function handler(data) {
                          if (data == "trade") {
                            _this3.chooseProduct();
                          } else if (data == "cash") {
                            _this3.paymentMethod = {
                              title: "Pay with Cash",
                              price: data.price,
                              image: "../../../assets/cash.png"
                            };
                            _this3.balance = 0;
                            _this3.total = _this3.subTotal;
                            console.log("No trade today sir.");
                          }
                        }
                      }]
                    });

                  case 2:
                    alert = _context2.sent;
                    _context2.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "chooseProduct",
        value: function chooseProduct() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this4 = this;

            var options, i, alert;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    options = [];

                    for (i = 0; i < this.products.length; ++i) {
                      options.push({
                        name: 'product',
                        type: 'radio',
                        value: this.products[i],
                        label: this.products[i].title + " - GHC" + this.products[i].price,
                        checked: i === 0
                      });
                    }

                    _context3.next = 4;
                    return this.alertController.create({
                      cssClass: 'my-custom-class',
                      header: 'Choose Product',
                      inputs: options,
                      buttons: [{
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler() {
                          console.log('Confirm Cancel');
                        }
                      }, {
                        text: 'Ok',
                        handler: function handler(data) {
                          _this4.paymentMethod = {
                            title: data.title,
                            price: data.price,
                            image: data.image
                          };

                          _this4.calcTotal();
                        }
                      }]
                    });

                  case 4:
                    alert = _context3.sent;
                    _context3.next = 7;
                    return alert.present();

                  case 7:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "paymentCancel",
        value: function paymentCancel() {
          console.log("Payment cancelled");
        }
      }, {
        key: "paymentDone",
        value: function paymentDone(ref) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var alert;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.alertController.create({
                      header: 'Offer Successful',
                      message: 'Your offer has been sent.',
                      buttons: ['OK']
                    });

                  case 2:
                    alert = _context4.sent;
                    _context4.next = 5;
                    return alert.present();

                  case 5:
                    this.router.navigateByUrl('/tabs/home');

                  case 6:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }]);

      return ShoppingCartPage;
    }();

    ShoppingCartPage.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
      }, {
        type: _services_product_service__WEBPACK_IMPORTED_MODULE_5__["ProductService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
      }];
    };

    ShoppingCartPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-shopping-cart',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./shopping-cart.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/shopping-cart/shopping-cart.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./shopping-cart.page.scss */
      "./src/app/pages/shopping-cart/shopping-cart.page.scss"))["default"]]
    })], ShoppingCartPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-shopping-cart-shopping-cart-module-es5.js.map