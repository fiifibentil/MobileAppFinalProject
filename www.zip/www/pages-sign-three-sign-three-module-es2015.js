(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-sign-three-sign-three-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sign-three/sign-three.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sign-three/sign-three.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\n\t<ion-toolbar>\n\t\t<!-- <ion-buttons slot=\"start\">\n\t\t\t<ion-menu-button></ion-menu-button>\n\t\t</ion-buttons> -->\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-back-button></ion-back-button>\n\t\t</ion-buttons>\n\t</ion-toolbar>\n</ion-header>\n<ion-content [fullscreen]=\"true\">\n\t<ion-grid class=\"ion-padding-horizontal\">\n\t\t<ion-row class=\"ion-padding-bottom\">\n\t\t\t<ion-col class=\"ion-text-center\">\n\t\t\t\t<h1 class=\"title\">Create an account</h1>\n\t\t\t\t<p class=\"mb ion-padding-horizontal\">\n\t\t\t\t\tCreate your account and join Shopify today.\n\t\t\t\t</p>\n\t\t\t</ion-col>\n\t\t</ion-row>\n\t\t<ion-row>\n\t\t\t<ion-col>\n\t\t\t\t<form [formGroup]=\"signForm\" (ngSubmit)=\"register()\">\n\t\t\t\t\t<ion-item lines=\"none\" class=\"ion-no-padding\">\n\t\t\t\t\t\t<ion-input placeholder=\"Username\" type=\"text\"  formControlName=\"username\">\n\t\t\t\t\t\t</ion-input>\n\t\t\t\t\t</ion-item>\n\t\t\t\t\t<div class=\"errors-container\" *ngIf=\"signForm.get('username').invalid && (signForm.get('username').dirty || signForm.get('username').touched)\">\n\t\t\t\t\t\t<ng-container *ngIf=\"signForm.get('username').errors.required\">Full Name is required</ng-container>\n\t\t\t\t\t</div>\n\t\t\t\t\t\n\t\t\t\t\t<ion-item lines=\"none\" class=\"ion-no-padding\">\n\t\t\t\t\t\t<ion-input placeholder=\"Email Address\" type=\"email\" formControlName=\"email\">\n\t\t\t\t\t\t</ion-input>\n\t\t\t\t\t</ion-item>\n\t\t\t\t\t<div class=\"errors-container\" *ngIf=\"signForm.get('email').invalid && (signForm.get('email').dirty || signForm.get('email').touched)\">\n\t\t\t\t\t\t<ng-container *ngIf=\"signForm.get('email').errors.required\">Email is required</ng-container>\n\t\t\t\t\t\t<ng-container *ngIf=\"signForm.get('email').errors.invalidEmail\">Email is invalid</ng-container>\n\t\t\t\t\t</div>\n\t\t\t\t\t\n\t\t\t\t\t<ion-item lines=\"none\" class=\"ion-no-padding\">\n\t\t\t\t\t\t<ion-input placeholder=\"Password\" type=\"password\"\n\t\t\t\t\t\t\tformControlName=\"password\"></ion-input>\n\t\t\t\t\t</ion-item>\n\t\t\t\t\t<div class=\"errors-container\" *ngIf=\"signForm.get('password').invalid && (signForm.get('password').dirty || signForm.get('password').touched)\">\n\t\t\t\t\t\t<ng-container *ngIf=\"signForm.get('password').errors.required\">Password is required</ng-container>\n\t\t\t\t\t\t<ng-container *ngIf=\"signForm.get('password').errors.invalidPassword\">{{ signForm.get('password').errors.message }}</ng-container>\n\t\t\t\t\t</div>\n\t\t\t\t\t\n\t\t\t\t\t<ion-item lines=\"none\" class=\"ion-no-padding\">\n\t\t\t\t\t\t<ion-input placeholder=\"Confirm Password\" type=\"password\"\n\t\t\t\t\t\t\tformControlName=\"password_confirm\"></ion-input>\n\t\t\t\t\t</ion-item>\n\t\t\t\t\t<div class=\"errors-container\" *ngIf=\"signForm.get('password').value != signForm.get('password_confirm').value && (signForm.get('password').dirty || signForm.get('password').touched)\">\n\t\t\t\t\t\t<ng-container>Passwords do not match</ng-container>\n\t\t\t\t\t</div>\n\n\t\t\t\t\t\n\t\t\t\t\t<ion-button [disabled]=\"signForm.invalid\" class=\"action-button ion-margin-top\" expand=\"block\" fill=\"solid\" color=\"primary\"\n\t\t\t\t\t\ttype=\"submit\">\n\t\t\t\t\t\t<span>Sign Up</span>\n\t\t\t\t\t</ion-button>\n\t\t\t\t</form>\n\t\t\t</ion-col>\n\t\t</ion-row>\n\t\t<!-- <ion-row>\n\t\t\t<ion-col class=\"ion-text-center ion-padding\">\n\t\t\t\tOr\n\t\t\t</ion-col>\n\t\t</ion-row> -->\n\t\t<!-- <ion-row>\n\t\t\t<ion-col>\n\t\t\t\t<ion-button class=\"social-button\" expand=\"block\" fill=\"solid\" color=\"facebook\">\n\t\t\t\t\t<ion-icon name=\"logo-facebook\" class=\"ion-padding-end\"></ion-icon>\n\t\t\t\t\t<span>Continue with Facebook</span>\n\t\t\t\t</ion-button>\n\t\t\t\t<ion-button class=\"social-button ion-margin-top\" expand=\"block\" fill=\"solid\" color=\"google\">\n\t\t\t\t\t<ion-icon name=\"logo-google\" class=\"ion-padding-end\"></ion-icon>\n\t\t\t\t\t<span>Continue with Google</span>\n\t\t\t\t</ion-button>\n\t\t\t</ion-col>\n\t\t</ion-row> -->\n\t</ion-grid>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/sign-three/sign-three-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/sign-three/sign-three-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: SignThreePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignThreePageRoutingModule", function() { return SignThreePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _sign_three_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sign-three.page */ "./src/app/pages/sign-three/sign-three.page.ts");




const routes = [
    {
        path: '',
        component: _sign_three_page__WEBPACK_IMPORTED_MODULE_3__["SignThreePage"]
    }
];
let SignThreePageRoutingModule = class SignThreePageRoutingModule {
};
SignThreePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SignThreePageRoutingModule);



/***/ }),

/***/ "./src/app/pages/sign-three/sign-three.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/sign-three/sign-three.module.ts ***!
  \*******************************************************/
/*! exports provided: SignThreePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignThreePageModule", function() { return SignThreePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _sign_three_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./sign-three-routing.module */ "./src/app/pages/sign-three/sign-three-routing.module.ts");
/* harmony import */ var _sign_three_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sign-three.page */ "./src/app/pages/sign-three/sign-three.page.ts");







let SignThreePageModule = class SignThreePageModule {
};
SignThreePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _sign_three_routing_module__WEBPACK_IMPORTED_MODULE_5__["SignThreePageRoutingModule"]
        ],
        declarations: [_sign_three_page__WEBPACK_IMPORTED_MODULE_6__["SignThreePage"]]
    })
], SignThreePageModule);



/***/ }),

/***/ "./src/app/pages/sign-three/sign-three.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/pages/sign-three/sign-three.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-toolbar {\n  --background: transparent;\n}\n\nh1.title {\n  font-weight: 600;\n  font-size: 28px;\n  line-height: 34px;\n  color: #151522;\n  padding: 0;\n  margin-top: 0;\n}\n\nion-text {\n  font-weight: 300;\n  font-size: 17px;\n  line-height: 24px;\n  color: #151522;\n}\n\nion-item {\n  --background: transparent;\n  --inner-padding-end: 0;\n}\n\nion-item ion-input {\n  border: 1px solid rgba(228, 228, 228, 0.6);\n  box-sizing: border-box;\n  border-radius: 5px;\n  background: #ffffff;\n  --padding-start: 16px;\n  margin-bottom: 8px;\n  min-height: 48px;\n}\n\nion-item ion-toggle {\n  --background: rgba(153, 153, 153, 0.8);\n}\n\n.action-button, .social-button {\n  --border-radius: 6px;\n  --box-shadow: none !important;\n  min-height: 48px;\n  box-shadow: 0px 4px 8px rgba(50, 50, 71, 0.06), 0px 4px 4px rgba(50, 50, 71, 0.08);\n}\n\n.action-button span, .social-button span {\n  font-weight: 300;\n  font-size: 16px;\n  line-height: 22px;\n  text-transform: initial;\n}\n\n.mb {\n  margin-bottom: 16px;\n}\n\n.errors-container {\n  font-size: 12px;\n  font-weight: 500;\n  color: var(--ion-color-danger);\n  margin-bottom: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2lnbi10aHJlZS9DOlxcVXNlcnNcXGhwXFxEZXNrdG9wXFxpb25pY19wcm9qZWN0c1xcRmluYWxQcm9qZWN0XFxzaG9waWZ5L3NyY1xcYXBwXFxwYWdlc1xcc2lnbi10aHJlZVxcc2lnbi10aHJlZS5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3NpZ24tdGhyZWUvc2lnbi10aHJlZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx5QkFBQTtBQ0NKOztBREVFO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsVUFBQTtFQUNBLGFBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVFO0VBQ0UseUJBQUE7RUFDQSxzQkFBQTtBQ0NKOztBRENJO0VBQ0UsMENBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNDTjs7QURFSTtFQUNFLHNDQUFBO0FDQU47O0FESUU7RUFDRSxvQkFBQTtFQUNBLDZCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrRkFBQTtBQ0RKOztBRElJO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSx1QkFBQTtBQ0ZOOztBRE1FO0VBQ0UsbUJBQUE7QUNISjs7QURNRTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLDhCQUFBO0VBQ0Esa0JBQUE7QUNISiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NpZ24tdGhyZWUvc2lnbi10aHJlZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIGlvbi10b29sYmFyIHtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICB9XG4gIFxuICBoMS50aXRsZSB7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXNpemU6IDI4cHg7XG4gICAgbGluZS1oZWlnaHQ6IDM0cHg7XG4gICAgY29sb3I6ICMxNTE1MjI7XG4gICAgcGFkZGluZzogMDtcbiAgICBtYXJnaW4tdG9wOiAwO1xuICB9XG4gIFxuICBpb24tdGV4dCB7XG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICBmb250LXNpemU6IDE3cHg7XG4gICAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gICAgY29sb3I6ICMxNTE1MjI7XG4gIH1cbiAgXG4gIGlvbi1pdGVtIHtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XG4gIFxuICAgIGlvbi1pbnB1dCB7XG4gICAgICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDIyOCwgMjI4LCAyMjgsIDAuNik7XG4gICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgYmFja2dyb3VuZDogI2ZmZmZmZjtcbiAgICAgIC0tcGFkZGluZy1zdGFydDogMTZweDtcbiAgICAgIG1hcmdpbi1ib3R0b206IDhweDtcbiAgICAgIG1pbi1oZWlnaHQ6IDQ4cHg7XG4gICAgfVxuICBcbiAgICBpb24tdG9nZ2xlIHtcbiAgICAgIC0tYmFja2dyb3VuZDogcmdiYSgxNTMsIDE1MywgMTUzLCAwLjgpO1xuICAgIH1cbiAgfVxuICBcbiAgLmFjdGlvbi1idXR0b24sIC5zb2NpYWwtYnV0dG9uIHtcbiAgICAtLWJvcmRlci1yYWRpdXM6IDZweDtcbiAgICAtLWJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgICBtaW4taGVpZ2h0OiA0OHB4O1xuICAgIGJveC1zaGFkb3c6IDBweCA0cHggOHB4IHJnYmEoNTAsIDUwLCA3MSwgMC4wNiksXG4gICAgICAwcHggNHB4IDRweCByZ2JhKDUwLCA1MCwgNzEsIDAuMDgpO1xuICBcbiAgICBzcGFuIHtcbiAgICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICBsaW5lLWhlaWdodDogMjJweDtcbiAgICAgIHRleHQtdHJhbnNmb3JtOiBpbml0aWFsO1xuICAgIH1cbiAgfVxuICBcbiAgLm1iIHtcbiAgICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICB9XG4gIFxuICAuZXJyb3JzLWNvbnRhaW5lciB7XG4gICAgZm9udC1zaXplOiAxMnB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYW5nZXIpO1xuICAgIG1hcmdpbi1ib3R0b206IDhweDtcbiAgfSIsImlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuXG5oMS50aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGZvbnQtc2l6ZTogMjhweDtcbiAgbGluZS1oZWlnaHQ6IDM0cHg7XG4gIGNvbG9yOiAjMTUxNTIyO1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW4tdG9wOiAwO1xufVxuXG5pb24tdGV4dCB7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gIGNvbG9yOiAjMTUxNTIyO1xufVxuXG5pb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XG59XG5pb24taXRlbSBpb24taW5wdXQge1xuICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDIyOCwgMjI4LCAyMjgsIDAuNik7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgYmFja2dyb3VuZDogI2ZmZmZmZjtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xuICBtYXJnaW4tYm90dG9tOiA4cHg7XG4gIG1pbi1oZWlnaHQ6IDQ4cHg7XG59XG5pb24taXRlbSBpb24tdG9nZ2xlIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKDE1MywgMTUzLCAxNTMsIDAuOCk7XG59XG5cbi5hY3Rpb24tYnV0dG9uLCAuc29jaWFsLWJ1dHRvbiB7XG4gIC0tYm9yZGVyLXJhZGl1czogNnB4O1xuICAtLWJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgbWluLWhlaWdodDogNDhweDtcbiAgYm94LXNoYWRvdzogMHB4IDRweCA4cHggcmdiYSg1MCwgNTAsIDcxLCAwLjA2KSwgMHB4IDRweCA0cHggcmdiYSg1MCwgNTAsIDcxLCAwLjA4KTtcbn1cbi5hY3Rpb24tYnV0dG9uIHNwYW4sIC5zb2NpYWwtYnV0dG9uIHNwYW4ge1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICB0ZXh0LXRyYW5zZm9ybTogaW5pdGlhbDtcbn1cblxuLm1iIHtcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcbn1cblxuLmVycm9ycy1jb250YWluZXIge1xuICBmb250LXNpemU6IDEycHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyKTtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/sign-three/sign-three.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/sign-three/sign-three.page.ts ***!
  \*****************************************************/
/*! exports provided: SignThreePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignThreePage", function() { return SignThreePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var src_app_validators_email_validators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/validators/email.validators */ "./src/app/validators/email.validators.ts");
/* harmony import */ var src_app_validators_password_validator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/validators/password.validator */ "./src/app/validators/password.validator.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/user.service */ "./src/app/services/user.service.ts");








let SignThreePage = class SignThreePage {
    constructor(userService, formBuilder, alertController, loadingController, router) {
        this.userService = userService;
        this.formBuilder = formBuilder;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.router = router;
    }
    ngOnInit() {
        this.signForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            'username': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'email': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, src_app_validators_email_validators__WEBPACK_IMPORTED_MODULE_3__["emailValidator"]]),
            'password': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, src_app_validators_password_validator__WEBPACK_IMPORTED_MODULE_4__["passwordValidator"]]),
            'password_confirm': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])
        }, this.passwordMatch);
    }
    register() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create();
            yield loading.present();
            this.userService.registerUser(this.signForm.get('username').value, this.signForm.get('email').value, this.signForm.get('password').value, this.signForm.get('password_confirm').value).subscribe((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                const alert = yield this.alertController.create({
                    header: 'Registration Successful',
                    message: 'Welcome to Baratto.',
                    buttons: ['OK'],
                });
                yield alert.present();
                this.router.navigateByUrl('/login');
            }), (res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                // show all values in the error object...map
                const alert = yield this.alertController.create({
                    header: 'Registration failed',
                    message: 'Failed to create account',
                    buttons: ['OK'],
                });
                yield alert.present();
            }));
        });
    }
    signIn() {
        if (this.signForm.valid) {
            this.userService.registerUser(this.signForm.get('username').value, this.signForm.get('email').value, this.signForm.get('password').value, this.signForm.get('password_confirm').value);
        }
        else {
            console.log('invalid');
        }
    }
    passwordMatch(frm) {
        if (frm.get('password').value !== frm.get('password_confirm').value) {
            return { invalid: true };
        }
    }
};
SignThreePage.ctorParameters = () => [
    { type: _services_user_service__WEBPACK_IMPORTED_MODULE_7__["UserService"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] }
];
SignThreePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-sign-three',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./sign-three.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sign-three/sign-three.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./sign-three.page.scss */ "./src/app/pages/sign-three/sign-three.page.scss")).default]
    })
], SignThreePage);



/***/ }),

/***/ "./src/app/validators/password.validator.ts":
/*!**************************************************!*\
  !*** ./src/app/validators/password.validator.ts ***!
  \**************************************************/
/*! exports provided: passwordValidator */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "passwordValidator", function() { return passwordValidator; });
function passwordValidator(control) {
    if (control && control.value !== null && control.value !== undefined) {
        const value = control.value;
        if (value.length < 8) {
            return {
                invalidPassword: true,
                message: 'Password must be at least 8 characters long',
            };
        }
        if (!/\d/.test(value)) {
            return {
                invalidPassword: true,
                message: 'The password must have a number',
            };
        }
        if (!/[a-z]/.test(value)) {
            return {
                invalidPassword: true,
                message: 'The password must have lowercase characters',
            };
        }
        if (!/[A-Z]/.test(value)) {
            return {
                invalidPassword: true,
                message: 'The password must have upercase characters',
            };
        }
        if (!/\W/.test(value)) {
            return {
                invalidPassword: true,
                message: 'The password must have special characters',
            };
        }
    }
    return null;
}


/***/ })

}]);
//# sourceMappingURL=pages-sign-three-sign-three-module-es2015.js.map