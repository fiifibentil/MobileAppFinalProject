function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-page-store-home-page-store-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home-page-store/home-page-store.page.html":
  /*!*******************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home-page-store/home-page-store.page.html ***!
    \*******************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesHomePageStoreHomePageStorePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons> -->\n    <ion-title>Explore</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\" class=\"ion-padding-horizontal\">\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col class=\"ion-no-padding\">\n        <app-product-collection [data]=\"ads\" [textShadow]=\"false\"></app-product-collection>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col class=\"ion-no-padding\">\n        <ion-item lines=\"none\" class=\"section\">\n          <ion-text color=\"dark\">\n            <h5>Recently Listed</h5>\n          </ion-text>\n          <ion-button\n            slot=\"end\"\n            fill=\"clear\"\n            size=\"small\"\n            shape=\"round\"\n            color=\"primary\"\n            [routerLink]=\"['/tabs/shop']\"\n          >\n            See All\n          </ion-button>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col class=\"ion-no-padding\">\n        <!-- Slides -->\n        <ion-slides [options]=\"slideConfig\">\n          <ion-slide *ngFor=\"let item of products.slice().reverse() | slice:0:5 \">\n            <app-product-card [product]=\"item\" [routerLink]=\"['/details', item.id]\"></app-product-card>\n          </ion-slide>\n        </ion-slides>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/home-page-store/home-page-store-routing.module.ts":
  /*!*************************************************************************!*\
    !*** ./src/app/pages/home-page-store/home-page-store-routing.module.ts ***!
    \*************************************************************************/

  /*! exports provided: HomePageStorePageRoutingModule */

  /***/
  function srcAppPagesHomePageStoreHomePageStoreRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageStorePageRoutingModule", function () {
      return HomePageStorePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _home_page_store_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./home-page-store.page */
    "./src/app/pages/home-page-store/home-page-store.page.ts");

    var routes = [{
      path: '',
      component: _home_page_store_page__WEBPACK_IMPORTED_MODULE_3__["HomePageStorePage"]
    }];

    var HomePageStorePageRoutingModule = function HomePageStorePageRoutingModule() {
      _classCallCheck(this, HomePageStorePageRoutingModule);
    };

    HomePageStorePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], HomePageStorePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/home-page-store/home-page-store.module.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/pages/home-page-store/home-page-store.module.ts ***!
    \*****************************************************************/

  /*! exports provided: HomePageStorePageModule */

  /***/
  function srcAppPagesHomePageStoreHomePageStoreModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageStorePageModule", function () {
      return HomePageStorePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _home_page_store_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./home-page-store-routing.module */
    "./src/app/pages/home-page-store/home-page-store-routing.module.ts");
    /* harmony import */


    var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/components/components.module */
    "./src/app/components/components.module.ts");
    /* harmony import */


    var _home_page_store_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./home-page-store.page */
    "./src/app/pages/home-page-store/home-page-store.page.ts");

    var HomePageStorePageModule = function HomePageStorePageModule() {
      _classCallCheck(this, HomePageStorePageModule);
    };

    HomePageStorePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _home_page_store_routing_module__WEBPACK_IMPORTED_MODULE_5__["HomePageStorePageRoutingModule"], src_app_components_components_module__WEBPACK_IMPORTED_MODULE_6__["ComponentsModule"]],
      declarations: [_home_page_store_page__WEBPACK_IMPORTED_MODULE_7__["HomePageStorePage"]]
    })], HomePageStorePageModule);
    /***/
  },

  /***/
  "./src/app/pages/home-page-store/home-page-store.page.scss":
  /*!*****************************************************************!*\
    !*** ./src/app/pages/home-page-store/home-page-store.page.scss ***!
    \*****************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesHomePageStoreHomePageStorePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".section {\n  --padding-start: 0;\n  --inner-padding-end: 0;\n  --background: none;\n}\n.section h5 {\n  font-size: 17px;\n  color: #151522;\n  font-weight: 600;\n  line-height: 22px;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG9tZS1wYWdlLXN0b3JlL0M6XFxVc2Vyc1xcaHBcXERlc2t0b3BcXGlvbmljX3Byb2plY3RzXFxGaW5hbFByb2plY3RcXHNob3BpZnkvc3JjXFxhcHBcXHBhZ2VzXFxob21lLXBhZ2Utc3RvcmVcXGhvbWUtcGFnZS1zdG9yZS5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2hvbWUtcGFnZS1zdG9yZS9ob21lLXBhZ2Utc3RvcmUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0FDQ0Y7QURDRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFNBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2hvbWUtcGFnZS1zdG9yZS9ob21lLXBhZ2Utc3RvcmUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNlY3Rpb24ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDA7XG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XG4gIC0tYmFja2dyb3VuZDogbm9uZTtcblxuICBoNSB7XG4gICAgZm9udC1zaXplOiAxN3B4O1xuICAgIGNvbG9yOiAjMTUxNTIyO1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XG4gICAgbWFyZ2luOiAwO1xuICB9XG59XG4iLCIuc2VjdGlvbiB7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbiAgLS1iYWNrZ3JvdW5kOiBub25lO1xufVxuLnNlY3Rpb24gaDUge1xuICBmb250LXNpemU6IDE3cHg7XG4gIGNvbG9yOiAjMTUxNTIyO1xuICBmb250LXdlaWdodDogNjAwO1xuICBsaW5lLWhlaWdodDogMjJweDtcbiAgbWFyZ2luOiAwO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/home-page-store/home-page-store.page.ts":
  /*!***************************************************************!*\
    !*** ./src/app/pages/home-page-store/home-page-store.page.ts ***!
    \***************************************************************/

  /*! exports provided: HomePageStorePage */

  /***/
  function srcAppPagesHomePageStoreHomePageStorePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageStorePage", function () {
      return HomePageStorePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _services_product_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../../services/product.service */
    "./src/app/services/product.service.ts");

    var HomePageStorePage = /*#__PURE__*/function () {
      function HomePageStorePage(productService) {
        _classCallCheck(this, HomePageStorePage);

        this.productService = productService; // products = [
        //   {
        //     image: 'assets/products/shoe1.png',
        //     title: 'Nike Runner XT 200',
        //     price: 245.99,
        //     category: 'Running',
        //     gradient: 'blue_to_pink',
        //     discount: '0.12'
        //   },
        //   {
        //     image: 'assets/products/shoe5.png',
        //     title: 'Nike Dual Fusion GT',
        //     price: 405.99,
        //     category: 'Running',
        //     gradient: 'blue_to_cyan'
        //   },
        //   {
        //     image: 'assets/products/shoe3.png',
        //     title: 'Nike Air Jordan Jnr',
        //     price: 99.99,
        //     category: 'Urban Style',
        //     gradient: 'navy_to_cyan',
        //     discount: '0.40'
        //   },
        //   {
        //     image: 'assets/products/shoe4.png',
        //     title: 'Nike Air Max Junior',
        //     price: 99.99,
        //     category: 'Urban Style',
        //     gradient: 'green_to_pink'
        //   },
        // ];

        this.products = [];
        this.categories = [];
        this.ads = {
          image: 'assets/products/shoe-ad.png',
          label: 'Sneakers',
          category: 'New Collection',
          gradient: 'blue_to_cyan'
        };
        this.slideConfig = {
          spaceBetween: 2,
          slidesPerView: 1.4
        };
        this.flashConfig = {
          spaceBetween: 2,
          slidesPerView: 2.3
        };
      }

      _createClass(HomePageStorePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          var _this = this;

          this.productService.getProducts().subscribe(function (products) {
            console.log(products);
            _this.products = products;
          });
          this.productService.getCategories().subscribe(function (categories) {
            _this.categories = categories;
          });
        }
      }]);

      return HomePageStorePage;
    }();

    HomePageStorePage.ctorParameters = function () {
      return [{
        type: _services_product_service__WEBPACK_IMPORTED_MODULE_2__["ProductService"]
      }];
    };

    HomePageStorePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-home-page-store',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./home-page-store.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home-page-store/home-page-store.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./home-page-store.page.scss */
      "./src/app/pages/home-page-store/home-page-store.page.scss"))["default"]]
    })], HomePageStorePage);
    /***/
  }
}]);
//# sourceMappingURL=home-page-store-home-page-store-module-es5.js.map