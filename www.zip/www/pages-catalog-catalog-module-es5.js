function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-catalog-catalog-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/catalog/catalog.page.html":
  /*!***************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/catalog/catalog.page.html ***!
    \***************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesCatalogCatalogPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\n    <ion-toolbar>\n      <!-- <ion-buttons slot=\"start\">\n        <ion-menu-button></ion-menu-button>\n      </ion-buttons> -->\n      <ion-buttons slot=\"start\">\n        <ion-back-button></ion-back-button>\n      </ion-buttons>\n      <ion-title>{{ category.title }}</ion-title>\n    </ion-toolbar>\n  </ion-header>\n  \n  <ion-content [fullscreen]=\"true\" class=\"ion-padding-horizontal\">\n    <ion-grid>\n      <ion-row class=\"ion-no-padding\">\n        <ion-col class=\"ion-padding-vertical\">\n          <ion-searchbar animated class=\"ion-no-padding\"></ion-searchbar>\n        </ion-col>\n      </ion-row>      \n      <ion-row>\n        <ion-col class=\"ion-no-padding\">\n          <ion-item lines=\"none\" class=\"section\">\n            <ion-text color=\"dark\">\n              <h5>Latest Products</h5>\n            </ion-text>\n            <ion-buttons slot=\"end\">\n              <ion-button\n              slot=\"end\"\n              fill=\"clear\"\n              size=\"small\"\n              shape=\"round\"\n              color=\"medium\"\n              class=\"small-button\"\n              (click)=\"changeView('grid')\"\n            >\n              <ion-icon slot=\"icon-only\" name=\"grid-outline\"></ion-icon>\n            </ion-button>\n\n            <ion-button\n              slot=\"end\"\n              fill=\"clear\"\n              size=\"small\"\n              shape=\"round\"\n              color=\"medium\"\n              class=\"small-button\"\n              (click)=\"changeView('card')\"\n            >\n              <ion-icon slot=\"icon-only\" name=\"square-outline\"></ion-icon>\n            </ion-button>\n            </ion-buttons>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"ion-no-padding\">\n        <ng-container [ngSwitch]=\"layout\">\n          <ng-container *ngSwitchCase=\"'grid'\">\n            <ion-col size=\"6\" *ngFor=\"let product of products\" class=\"ion-no-padding\">\n              <app-product-card-sm [data]=\"product\" [routerLink]=\"['/details/', product.id]\"></app-product-card-sm>\n            </ion-col>\n          </ng-container>\n          <ng-container *ngSwitchCase=\"'card'\">\n            <ion-col  size=\"12\" *ngFor=\"let product of products\" class=\"ion-no-padding\">\n              <app-product-card-md [data]=\"product\" [routerLink]=\"['/details/', product.id]\"></app-product-card-md>\n            </ion-col>\n          </ng-container>\n          \n        </ng-container>\n\n      </ion-row>\n    </ion-grid>\n  </ion-content>\n  ";
    /***/
  },

  /***/
  "./src/app/pages/catalog/catalog-routing.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/pages/catalog/catalog-routing.module.ts ***!
    \*********************************************************/

  /*! exports provided: CatalogPageRoutingModule */

  /***/
  function srcAppPagesCatalogCatalogRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CatalogPageRoutingModule", function () {
      return CatalogPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _catalog_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./catalog.page */
    "./src/app/pages/catalog/catalog.page.ts");

    var routes = [{
      path: '',
      component: _catalog_page__WEBPACK_IMPORTED_MODULE_3__["CatalogPage"]
    }];

    var CatalogPageRoutingModule = function CatalogPageRoutingModule() {
      _classCallCheck(this, CatalogPageRoutingModule);
    };

    CatalogPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], CatalogPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/catalog/catalog.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/pages/catalog/catalog.module.ts ***!
    \*************************************************/

  /*! exports provided: CatalogPageModule */

  /***/
  function srcAppPagesCatalogCatalogModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CatalogPageModule", function () {
      return CatalogPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _catalog_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./catalog-routing.module */
    "./src/app/pages/catalog/catalog-routing.module.ts");
    /* harmony import */


    var _catalog_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./catalog.page */
    "./src/app/pages/catalog/catalog.page.ts");
    /* harmony import */


    var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/components/components.module */
    "./src/app/components/components.module.ts");

    var CatalogPageModule = function CatalogPageModule() {
      _classCallCheck(this, CatalogPageModule);
    };

    CatalogPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _catalog_routing_module__WEBPACK_IMPORTED_MODULE_5__["CatalogPageRoutingModule"], src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]],
      declarations: [_catalog_page__WEBPACK_IMPORTED_MODULE_6__["CatalogPage"]]
    })], CatalogPageModule);
    /***/
  },

  /***/
  "./src/app/pages/catalog/catalog.page.scss":
  /*!*************************************************!*\
    !*** ./src/app/pages/catalog/catalog.page.scss ***!
    \*************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesCatalogCatalogPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-searchbar {\n  --box-shadow: 0 !important;\n  --border-radius: 8px;\n  --background: var(--ion-color-light);\n  --color: var(--ion-color-medium);\n}\n\n.section {\n  --padding-start: 0;\n  --inner-padding-end: 0;\n}\n\n.section h5 {\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY2F0YWxvZy9DOlxcVXNlcnNcXGhwXFxEZXNrdG9wXFxpb25pY19wcm9qZWN0c1xcRmluYWxQcm9qZWN0XFxzaG9waWZ5L3NyY1xcYXBwXFxwYWdlc1xcY2F0YWxvZ1xcY2F0YWxvZy5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2NhdGFsb2cvY2F0YWxvZy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSwwQkFBQTtFQUNBLG9CQUFBO0VBQ0Esb0NBQUE7RUFDQSxnQ0FBQTtBQ0NKOztBREdBO0VBQ0Usa0JBQUE7RUFDQSxzQkFBQTtBQ0FGOztBREVFO0VBQ0UsU0FBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvY2F0YWxvZy9jYXRhbG9nLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1zZWFyY2hiYXIge1xuICAgIC0tYm94LXNoYWRvdzogMCAhaW1wb3J0YW50O1xuICAgIC0tYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbn1cblxuXG4uc2VjdGlvbiB7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcblxuICBoNSB7XG4gICAgbWFyZ2luOiAwO1xuICB9XG59XG4iLCJpb24tc2VhcmNoYmFyIHtcbiAgLS1ib3gtc2hhZG93OiAwICFpbXBvcnRhbnQ7XG4gIC0tYm9yZGVyLXJhZGl1czogOHB4O1xuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG4gIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xufVxuXG4uc2VjdGlvbiB7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbn1cbi5zZWN0aW9uIGg1IHtcbiAgbWFyZ2luOiAwO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/catalog/catalog.page.ts":
  /*!***********************************************!*\
    !*** ./src/app/pages/catalog/catalog.page.ts ***!
    \***********************************************/

  /*! exports provided: CatalogPage */

  /***/
  function srcAppPagesCatalogCatalogPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CatalogPage", function () {
      return CatalogPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _services_product_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../../services/product.service */
    "./src/app/services/product.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var CatalogPage = /*#__PURE__*/function () {
      function CatalogPage(productService, activatedRoute) {
        _classCallCheck(this, CatalogPage);

        this.productService = productService;
        this.activatedRoute = activatedRoute;
        this.layout = 'grid';
        this.products = [];
        this.category = {};
        this.items = [{
          image: 'https://images.unsplash.com/photo-1563903530908-afdd155d057a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80',
          text: 'Chanel Sunglasses UV Summer Ultra',
          price: 149,
          badge: ''
        }, {
          image: 'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=343&q=80',
          text: 'Vans Winnie SK8 Low Rider',
          price: 199.99,
          badge: '-10%'
        }, {
          image: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80',
          text: 'Polaroid Instant Max 2020 Model',
          price: 299.99,
          badge: ''
        }, {
          image: 'https://images.unsplash.com/photo-1520256862855-398228c41684?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80',
          text: 'Nike Air Jordan Ultra Run',
          price: 1542.59,
          badge: ''
        }, {
          image: 'https://images.unsplash.com/photo-1491637639811-60e2756cc1c7?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80',
          text: 'Hikking Bag Pack Off Road Camo',
          price: 14.99,
          badge: ''
        }];
      }

      _createClass(CatalogPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          var _this = this;

          var id = this.activatedRoute.snapshot.paramMap.get('id');
          this.productService.getCategory(id).subscribe(function (category) {
            _this.category = category;
          });
          this.productService.getCategoryProducts(id).subscribe(function (products) {
            _this.products = products;
          });
        }
      }, {
        key: "changeView",
        value: function changeView(param) {
          switch (param) {
            case 'grid':
              this.layout = 'grid';
              break;

            case 'card':
              this.layout = 'card';
              break;

            default:
              this.layout = 'grid';
              break;
          }
        }
      }]);

      return CatalogPage;
    }();

    CatalogPage.ctorParameters = function () {
      return [{
        type: _services_product_service__WEBPACK_IMPORTED_MODULE_2__["ProductService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }];
    };

    CatalogPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-catalog',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./catalog.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/catalog/catalog.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./catalog.page.scss */
      "./src/app/pages/catalog/catalog.page.scss"))["default"]]
    })], CatalogPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-catalog-catalog-module-es5.js.map