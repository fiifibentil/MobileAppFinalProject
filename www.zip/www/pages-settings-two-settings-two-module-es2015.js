(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-settings-two-settings-two-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/settings-two/settings-two.page.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/settings-two/settings-two.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>Settings</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-list>\n    <ion-list-header>\n      <ion-label>Account settings</ion-label>\n    </ion-list-header>\n\n    <ion-item (click)=\"logout()\">\n      <ion-label class=\"ion-padding-start\">\n        Logout\n      </ion-label>\n    </ion-item>\n  </ion-list>\n\n  <!-- <ion-list>\n    <ion-list-header>\n      <ion-label>Preferences</ion-label>\n    </ion-list-header>\n    <ion-item>\n      <ion-label  class=\"ion-padding-start\">\n        Keep Browse History\n      </ion-label>\n      <ion-toggle slot=\"end\" mode=\"ios\" color=\"primary\" checked></ion-toggle>\n    </ion-item>\n    <ion-item>\n      <ion-label class=\"ion-padding-start\">\n        Clear All Data\n      </ion-label>\n      <ion-icon class=\"ion-padding-end\" color=\"danger\" slot=\"end\" name=\"trash-outline\"></ion-icon>\n    </ion-item>\n  </ion-list>\n  <ion-list>\n    <ion-list-header>\n      <ion-label>Support</ion-label>\n    </ion-list-header>\n    <ion-item>\n      <ion-label class=\"ion-padding-start\">\n        Help Center\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label class=\"ion-padding-start\">\n        FAQs\n      </ion-label>\n    </ion-item>\n  </ion-list> -->\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/settings-two/settings-two-routing.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/settings-two/settings-two-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: SettingsTwoPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsTwoPageRoutingModule", function() { return SettingsTwoPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _settings_two_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./settings-two.page */ "./src/app/pages/settings-two/settings-two.page.ts");




const routes = [
    {
        path: '',
        component: _settings_two_page__WEBPACK_IMPORTED_MODULE_3__["SettingsTwoPage"]
    }
];
let SettingsTwoPageRoutingModule = class SettingsTwoPageRoutingModule {
};
SettingsTwoPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SettingsTwoPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/settings-two/settings-two.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/settings-two/settings-two.module.ts ***!
  \***********************************************************/
/*! exports provided: SettingsTwoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsTwoPageModule", function() { return SettingsTwoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _settings_two_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./settings-two-routing.module */ "./src/app/pages/settings-two/settings-two-routing.module.ts");
/* harmony import */ var _settings_two_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./settings-two.page */ "./src/app/pages/settings-two/settings-two.page.ts");







let SettingsTwoPageModule = class SettingsTwoPageModule {
};
SettingsTwoPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _settings_two_routing_module__WEBPACK_IMPORTED_MODULE_5__["SettingsTwoPageRoutingModule"]
        ],
        declarations: [_settings_two_page__WEBPACK_IMPORTED_MODULE_6__["SettingsTwoPage"]]
    })
], SettingsTwoPageModule);



/***/ }),

/***/ "./src/app/pages/settings-two/settings-two.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/pages/settings-two/settings-two.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-item {\n  --padding-start: 0;\n  --inner-padding-end: 0;\n}\nion-item ion-label {\n  font-weight: 300;\n  font-size: 15px;\n  line-height: 22px;\n  color: #151522;\n}\nion-list-header {\n  font-weight: 600;\n  font-size: 17px;\n  line-height: 22px;\n  color: var(--ion-color-facebook);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2V0dGluZ3MtdHdvL0M6XFxVc2Vyc1xcaHBcXERlc2t0b3BcXGlvbmljX3Byb2plY3RzXFxGaW5hbFByb2plY3RcXHNob3BpZnkvc3JjXFxhcHBcXHBhZ2VzXFxzZXR0aW5ncy10d29cXHNldHRpbmdzLXR3by5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3NldHRpbmdzLXR3by9zZXR0aW5ncy10d28ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxzQkFBQTtBQ0NGO0FEQ0U7RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUNDSjtBREdBO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQ0FBQTtBQ0FGIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvc2V0dGluZ3MtdHdvL3NldHRpbmdzLXR3by5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taXRlbSB7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcblxuICBpb24tbGFiZWwge1xuICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgZm9udC1zaXplOiAxNXB4O1xuICAgIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICAgIGNvbG9yOiAjMTUxNTIyO1xuICB9XG59XG5cbmlvbi1saXN0LWhlYWRlciB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgbGluZS1oZWlnaHQ6IDIycHg7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZmFjZWJvb2spO1xufVxuIiwiaW9uLWl0ZW0ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDA7XG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XG59XG5pb24taXRlbSBpb24tbGFiZWwge1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDE1cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICBjb2xvcjogIzE1MTUyMjtcbn1cblxuaW9uLWxpc3QtaGVhZGVyIHtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBsaW5lLWhlaWdodDogMjJweDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1mYWNlYm9vayk7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/settings-two/settings-two.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/settings-two/settings-two.page.ts ***!
  \*********************************************************/
/*! exports provided: SettingsTwoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsTwoPage", function() { return SettingsTwoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/user.service */ "./src/app/services/user.service.ts");





let SettingsTwoPage = class SettingsTwoPage {
    constructor(router, alertController, userService) {
        this.router = router;
        this.alertController = alertController;
        this.userService = userService;
    }
    ngOnInit() {
    }
    logout() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.userService.logout();
            this.router.navigateByUrl('/', { replaceUrl: true });
        });
    }
};
SettingsTwoPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"] }
];
SettingsTwoPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-settings-two',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./settings-two.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/settings-two/settings-two.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./settings-two.page.scss */ "./src/app/pages/settings-two/settings-two.page.scss")).default]
    })
], SettingsTwoPage);



/***/ })

}]);
//# sourceMappingURL=pages-settings-two-settings-two-module-es2015.js.map