(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-edit-product-edit-product-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/edit-product/edit-product.page.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/edit-product/edit-product.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-title>Edit Product</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-grid class=\"ion-padding-horizontal\">\n    <ion-row>\n      <ion-col>\n        <form [formGroup]=\"editForm\" (ngSubmit)=\"submitProduct()\">\n          <ion-item>\n            <ion-label position=\"floating\" class=\"ion-no-padding\">Clothing Item Name <ion-text color=\"danger\">*</ion-text></ion-label>\n            <ion-input required formControlName=\"productName\" type=\"text\"></ion-input>\n          </ion-item>\n          <ion-item>\n            <ion-label position=\"floating\" class=\"ion-no-padding\">Price (GHC) <ion-text color=\"danger\">*</ion-text></ion-label>\n            <ion-input required formControlName=\"price\" type=\"text\"></ion-input>\n          </ion-item>\n          <ion-item>\n            <ion-label position=\"floating\" class=\"ion-no-padding\">Description <ion-text color=\"danger\">*</ion-text></ion-label>\n            <ion-input required formControlName=\"description\" type=\"text\"></ion-input>\n          </ion-item>\n\n          <ion-item class=\"ion-no-padding\">\n            <ion-button (click)=\"chooseOrTakePicture()\" expand=\"block\" fill=\"clear\" shape=\"round\">\n              Choose Image\n            </ion-button>\n          </ion-item>\n          \n          <ion-button block color=\"primary\" type=\"submit\" [disabled]=\"editForm.invalid\">\n            Edit Product\n          </ion-button>\n        </form>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/edit-product/edit-product-routing.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/edit-product/edit-product-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: EditProductPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditProductPageRoutingModule", function() { return EditProductPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _edit_product_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./edit-product.page */ "./src/app/pages/edit-product/edit-product.page.ts");




const routes = [
    {
        path: '',
        component: _edit_product_page__WEBPACK_IMPORTED_MODULE_3__["EditProductPage"]
    }
];
let EditProductPageRoutingModule = class EditProductPageRoutingModule {
};
EditProductPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditProductPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/edit-product/edit-product.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/edit-product/edit-product.module.ts ***!
  \***********************************************************/
/*! exports provided: EditProductPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditProductPageModule", function() { return EditProductPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _edit_product_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./edit-product-routing.module */ "./src/app/pages/edit-product/edit-product-routing.module.ts");
/* harmony import */ var _edit_product_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit-product.page */ "./src/app/pages/edit-product/edit-product.page.ts");







let EditProductPageModule = class EditProductPageModule {
};
EditProductPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _edit_product_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditProductPageRoutingModule"]
        ],
        declarations: [_edit_product_page__WEBPACK_IMPORTED_MODULE_6__["EditProductPage"]]
    })
], EditProductPageModule);



/***/ }),

/***/ "./src/app/pages/edit-product/edit-product.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/pages/edit-product/edit-product.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-select {\n  width: 100%;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZWRpdC1wcm9kdWN0L0M6XFxVc2Vyc1xcaHBcXERlc2t0b3BcXGlvbmljX3Byb2plY3RzXFxGaW5hbFByb2plY3RcXHNob3BpZnkvc3JjXFxhcHBcXHBhZ2VzXFxlZGl0LXByb2R1Y3RcXGVkaXQtcHJvZHVjdC5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2VkaXQtcHJvZHVjdC9lZGl0LXByb2R1Y3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUVBLHVCQUFBO0FDQUoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9lZGl0LXByb2R1Y3QvZWRpdC1wcm9kdWN0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1zZWxlY3Qge1xuICAgIHdpZHRoOiAxMDAlO1xuICBcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgfSIsImlvbi1zZWxlY3Qge1xuICB3aWR0aDogMTAwJTtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/edit-product/edit-product.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/edit-product/edit-product.page.ts ***!
  \*********************************************************/
/*! exports provided: EditProductPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditProductPage", function() { return EditProductPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/product.service */ "./src/app/services/product.service.ts");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");







const { Camera } = _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Plugins"];
let EditProductPage = class EditProductPage {
    constructor(productService, formBuilder, alertController, loadingController, plt, actionSheetController, activatedRoute) {
        this.productService = productService;
        this.formBuilder = formBuilder;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.plt = plt;
        this.actionSheetController = actionSheetController;
        this.activatedRoute = activatedRoute;
        this.categories = [];
        this.product = {};
        this.formData = new FormData();
        this.id = this.activatedRoute.snapshot.paramMap.get('id');
    }
    ngOnInit() {
        this.editForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            'productName': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, []),
            'price': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, []),
            'description': new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, []),
        });
    }
    ionViewWillEnter() {
        this.productService.getProduct(this.id).subscribe(result => {
            this.product = result;
            this.productName.setValue(this.product.title);
            this.price.setValue(this.product.price);
            this.description.setValue(this.product.description);
        });
    }
    submitProduct() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.formData.append("title", this.productName.value);
            this.formData.append("price", this.price.value);
            this.formData.append("description", this.description.value);
            const loading = yield this.loadingController.create();
            yield loading.present();
            this.productService.editProduct(this.product.id, this.formData).subscribe((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                const alert = yield this.alertController.create({
                    header: 'Listing Edited',
                    message: 'Your product listing has been edited',
                    buttons: ['OK'],
                });
                yield alert.present();
            }), (res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                const alert = yield this.alertController.create({
                    header: 'Listing Edit Failed',
                    message: 'Failed to edit product listing',
                    buttons: ['OK'],
                });
                yield alert.present();
            }));
        });
    }
    chooseOrTakePicture() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const image = yield _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Plugins"].Camera.getPhoto({
                quality: 90,
                allowEditing: false,
                resultType: _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["CameraResultType"].Base64,
            }).catch((error) => {
                console.log(error);
            });
            // variable image should contain our base64 image
            if (image) {
                // convert base64 image to blob
                let blob = this.b64toBlob(image.base64String);
                //Generate a fake filename
                let name = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 10);
                this.formData.append('image', blob, name + `.${image.format}`);
            }
        });
    }
    b64toBlob(b64Data, contentType = '', sliceSize = 512) {
        const byteCharacters = atob(b64Data);
        const byteArrays = [];
        for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            const slice = byteCharacters.slice(offset, offset + sliceSize);
            const byteNumbers = new Array(slice.length);
            for (let i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
        }
        const blob = new Blob(byteArrays, { type: contentType });
        return blob;
    }
    get productName() {
        return this.editForm.get('productName');
    }
    get price() {
        return this.editForm.get('price');
    }
    get description() {
        return this.editForm.get('description');
    }
};
EditProductPage.ctorParameters = () => [
    { type: _services_product_service__WEBPACK_IMPORTED_MODULE_4__["ProductService"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] }
];
EditProductPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-edit-product',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./edit-product.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/edit-product/edit-product.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./edit-product.page.scss */ "./src/app/pages/edit-product/edit-product.page.scss")).default]
    })
], EditProductPage);



/***/ })

}]);
//# sourceMappingURL=pages-edit-product-edit-product-module-es2015.js.map