import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settings-one',
  templateUrl: './settings-one.page.html',
  styleUrls: ['./settings-one.page.scss'],
})
export class SettingsOnePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
